/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Carrental.Admin;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Lashvin
 */
public class CarDetails {
    String NoPlate;
    String CarType;
    String CarBrand;
    String CarColour;
    String Mileage;
    String Price;
    
    
    public CarDetails(String NoPlate,String CarType,String CarBrand,String CarColour,String Mileage,String Price){
        this.NoPlate = NoPlate;
        this.CarType = CarType;
        this.CarBrand = CarBrand;
        this.CarColour = CarColour;
        this.Mileage = Mileage;
        this.Price = Price;
    }
    public void AddCar(){
        try{
            BufferedWriter Car = new BufferedWriter (new FileWriter(("Cars.txt"),true));
            Car.write(NoPlate + ":" + CarType + ":" + CarBrand + ":" + CarColour + ":" + Mileage + ":" + Price + ":" + "Available");
            Car.newLine();
            Car.close();
        }catch(IOException e){}
    }
    
    public static void UpdateCar(String NoPlate, String CarType,String CarBrand,String CarColour,String Mileage,String Price){
        
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("Cars.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String NumberPlate = (records[0]);
                String Available = (records[6]);
                if (NoPlate.equals(records[0])){
                    modifyArray.add(NumberPlate + ":" + CarType + ":" + CarBrand + ":" + CarColour + ":" + Mileage + ":" + Price + ":" + Available);
                }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("Cars.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Admin details");
        }
    }
    
    public static void delete(String NoPlate){
        String[] records;
        String line;
        File file = new File("Cars.txt");
        File temp = new File("Temp.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(file));
            BufferedWriter writer = new BufferedWriter(new FileWriter(temp)))  {
            while ((line = reader.readLine()) != null) {
                records = line.split(":");

                String CarNoPlate  = (records[0]);
                String CarType = (records[1]);
                String CarBrand = (records[2]);
                String CarColour = (records[3]);
                String Mileage = (records[4]);
                String Price = (records[5]);
                if (!CarNoPlate.equals(NoPlate)){
                    writer.write(CarNoPlate + ":" + CarType + ":" + CarBrand + ":" + CarColour + ":" + Mileage + ":" + Price + ":" + "Available");
                    writer.newLine();
                } 
            }
            reader.close();
            writer.close();
            file.delete();
            temp.renameTo(file);
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
    }
    
    public static void Approve(String BookingID ,String CarNoPlate,String IcNumber,String CarModel,String StartDate,String EndDate,String RentFee,String Status){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("CarBookings.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String ICNumber = (records[2]);
                String Car_NOPLATE = (records[1]);
                if (IcNumber.equals(ICNumber)&& CarNoPlate.equals(Car_NOPLATE)&& Status.equals("Pending")){
                    
                    modifyArray.add(BookingID + ":" +CarNoPlate + ":" + IcNumber + ":" + CarModel + ":" + StartDate + ":" + EndDate + ":" + RentFee +":"+ "Approved");
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("CarBookings.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
    
    
    public static void Declined(String BookingID ,String CarNoPlate,String IcNumber,String CarModel,String StartDate,String EndDate,String RentFee,String Status){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("CarBookings.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String ICNumber = (records[2]);
                String Car_NOPLATE = (records[1]);
                if (IcNumber.equals(ICNumber)&& CarNoPlate.equals(Car_NOPLATE)&& Status.equals("Pending") ){
                    
                    modifyArray.add(BookingID + ":" +CarNoPlate + ":" + IcNumber + ":" + CarModel + ":" + StartDate + ":" + EndDate + ":" + RentFee +":"+ "Declined");
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("CarBookings.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
    
    public static void NotAvailableCarInfo(String carNumberPlate){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("Cars.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String NumberPlate = (records[0]);
                String CarType = (records[1]);
                String CarBrand = (records[2]);
                String CarColour = (records[3]);
                String Mileage = (records[4]);
                String Price = (records[5]);   
                if (carNumberPlate.equals(NumberPlate)){
                    modifyArray.add(NumberPlate + ":" + CarType + ":" + CarBrand + ":" + CarColour + ":" + Mileage + ":" + Price + ":" +"Not_Available");
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("Cars.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
    
    public static void AvailableCarInfo(String carNumberPlate){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("Cars.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String NumberPlate = (records[0]);
                String CarType = (records[1]);
                String CarBrand = (records[2]);
                String CarColour = (records[3]);
                String Mileage = (records[4]);
                String Price = (records[5]);  
                String Availablity = (records[6]);
                if (carNumberPlate.equals(NumberPlate)&& Availablity.equals("Not_Available")){
                    modifyArray.add(NumberPlate + ":" + CarType + ":" + CarBrand + ":" + CarColour + ":" + Mileage + ":" + Price + ":" +"Available");
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("Cars.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
    
}
