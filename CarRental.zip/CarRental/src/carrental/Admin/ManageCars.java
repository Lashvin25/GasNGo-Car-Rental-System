/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package carrental.Admin;


import Carrental.Admin.CarDetails;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Lashvin
 */
public class ManageCars extends javax.swing.JInternalFrame {

    /**
     * Creates new form ManageCars
     */
    public ManageCars() {
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI)this.getUI();
        ui.setNorthPane(null);
        DisplayCar();
    }

    public void DisplayCar(){
        String FilePath = "Cars.txt";
            File CarDetails = new File(FilePath);
            
            try{
                BufferedReader Car = new BufferedReader(new FileReader(CarDetails));
                DefaultTableModel model = (DefaultTableModel)CarDetailsTable.getModel();
                Object[] Lines = Car.lines().toArray();
                for(int i=0; i < Lines.length; i++){
                    String Line = Lines[i].toString().trim();
                    String[] dataRow = Line.split(":");
                    model.addRow(dataRow);
                }
                Car.close();
            }catch (IOException ex){
                
            }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ManageCarPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        CarDetailsTable = new javax.swing.JTable();
        AddBtn = new javax.swing.JButton();
        UpdateBtn = new javax.swing.JButton();
        DeleteBtn = new javax.swing.JButton();
        UpdateTableBtn = new javax.swing.JButton();
        Available = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        SignUpQLabel2 = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(770, 550));
        getContentPane().setLayout(null);

        ManageCarPanel.setBackground(new java.awt.Color(255, 255, 255));
        ManageCarPanel.setMaximumSize(new java.awt.Dimension(770, 560));
        ManageCarPanel.setMinimumSize(new java.awt.Dimension(770, 560));
        ManageCarPanel.setPreferredSize(new java.awt.Dimension(770, 560));
        ManageCarPanel.setLayout(null);

        CarDetailsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No Plate", "Car Type", "Car Model", "Car Colour", "Mileage", "Price Per Hour", "Availability"
            }
        ));
        jScrollPane1.setViewportView(CarDetailsTable);

        ManageCarPanel.add(jScrollPane1);
        jScrollPane1.setBounds(10, 70, 730, 330);

        AddBtn.setBackground(new java.awt.Color(0, 0, 0));
        AddBtn.setFont(new java.awt.Font("Franklin Gothic Book", 1, 12)); // NOI18N
        AddBtn.setForeground(new java.awt.Color(255, 255, 255));
        AddBtn.setText("ADD");
        AddBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddBtnMouseClicked(evt);
            }
        });
        AddBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddBtnActionPerformed(evt);
            }
        });
        ManageCarPanel.add(AddBtn);
        AddBtn.setBounds(40, 420, 120, 40);

        UpdateBtn.setBackground(new java.awt.Color(0, 0, 0));
        UpdateBtn.setFont(new java.awt.Font("Franklin Gothic Book", 1, 12)); // NOI18N
        UpdateBtn.setForeground(new java.awt.Color(255, 255, 255));
        UpdateBtn.setText("UPDATE");
        UpdateBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UpdateBtnMouseClicked(evt);
            }
        });
        ManageCarPanel.add(UpdateBtn);
        UpdateBtn.setBounds(170, 420, 120, 40);

        DeleteBtn.setBackground(new java.awt.Color(0, 0, 0));
        DeleteBtn.setFont(new java.awt.Font("Franklin Gothic Book", 1, 12)); // NOI18N
        DeleteBtn.setForeground(new java.awt.Color(255, 255, 255));
        DeleteBtn.setText("DELETE");
        DeleteBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DeleteBtnMouseClicked(evt);
            }
        });
        ManageCarPanel.add(DeleteBtn);
        DeleteBtn.setBounds(300, 420, 120, 40);

        UpdateTableBtn.setBackground(new java.awt.Color(0, 0, 0));
        UpdateTableBtn.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        UpdateTableBtn.setForeground(new java.awt.Color(255, 255, 255));
        UpdateTableBtn.setText("UPDATE TABLE");
        UpdateTableBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UpdateTableBtnMouseClicked(evt);
            }
        });
        ManageCarPanel.add(UpdateTableBtn);
        UpdateTableBtn.setBounds(583, 15, 150, 30);

        Available.setBackground(new java.awt.Color(0, 0, 0));
        Available.setFont(new java.awt.Font("Franklin Gothic Book", 1, 12)); // NOI18N
        Available.setForeground(new java.awt.Color(255, 255, 255));
        Available.setText("AVAILABLE");
        Available.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AvailableMouseClicked(evt);
            }
        });
        ManageCarPanel.add(Available);
        Available.setBounds(580, 420, 120, 40);

        jPanel5.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        ManageCarPanel.add(jPanel5);
        jPanel5.setBounds(50, 10, 10, 40);

        jLabel5.setFont(new java.awt.Font("Rockwell", 3, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("MANAGE CARS");
        ManageCarPanel.add(jLabel5);
        jLabel5.setBounds(70, 0, 500, 60);

        SignUpQLabel2.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        SignUpQLabel2.setForeground(new java.awt.Color(153, 153, 153));
        SignUpQLabel2.setText("Make car available in system");
        ManageCarPanel.add(SignUpQLabel2);
        SignUpQLabel2.setBounds(570, 470, 180, 20);

        getContentPane().add(ManageCarPanel);
        ManageCarPanel.setBounds(0, 0, 790, 560);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddBtnMouseClicked
        AddBtnOption AO = new AddBtnOption();
        AO.setVisible(true);
    }//GEN-LAST:event_AddBtnMouseClicked

    private void AddBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddBtnActionPerformed
        
    }//GEN-LAST:event_AddBtnActionPerformed

    private void UpdateBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdateBtnMouseClicked
        UpdBtnOption UO = new UpdBtnOption();
        UO.setVisible(true);
    }//GEN-LAST:event_UpdateBtnMouseClicked

    private void DeleteBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeleteBtnMouseClicked
        DeleteBtnOption DO = new DeleteBtnOption();
        DO.setVisible(true);
    }//GEN-LAST:event_DeleteBtnMouseClicked

    private void UpdateTableBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdateTableBtnMouseClicked
        DefaultTableModel model = (DefaultTableModel)CarDetailsTable.getModel();
        model.setRowCount(0);
        DisplayCar();
    }//GEN-LAST:event_UpdateTableBtnMouseClicked

    private void AvailableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AvailableMouseClicked
        String CarNoPlate;
        int selectedRow = CarDetailsTable.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)CarDetailsTable.getModel();
        CarNoPlate = model.getValueAt(selectedRow,0).toString();
        CarDetails.AvailableCarInfo(CarNoPlate);
    }//GEN-LAST:event_AvailableMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddBtn;
    private javax.swing.JButton Available;
    private javax.swing.JTable CarDetailsTable;
    private javax.swing.JButton DeleteBtn;
    private javax.swing.JPanel ManageCarPanel;
    private javax.swing.JLabel SignUpQLabel2;
    private javax.swing.JButton UpdateBtn;
    private javax.swing.JButton UpdateTableBtn;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
