/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package carrental.Admin;

import Carrental.Admin.CarDetails;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author Lashvin
 */
public class UpdBtnOption extends javax.swing.JFrame {

    /**
     * Creates new form UpdBtnOption
     */
    public UpdBtnOption() {
        initComponents();
        Toolkit toolkit= getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        UpdatePanel = new javax.swing.JPanel();
        MileageLbl = new javax.swing.JLabel();
        NoPlatelbl = new javax.swing.JLabel();
        PriceLbl = new javax.swing.JLabel();
        Line3Lbl = new javax.swing.JLabel();
        Line6Lbl = new javax.swing.JLabel();
        NoPlatetxt = new javax.swing.JTextField();
        Pricetxt = new javax.swing.JTextField();
        CarTypeLbl = new javax.swing.JLabel();
        CarTypeCB = new javax.swing.JComboBox<>();
        CarBrandLbl = new javax.swing.JLabel();
        CarBrandCB = new javax.swing.JComboBox<>();
        CarColourLbl = new javax.swing.JLabel();
        SearchBtn = new javax.swing.JButton();
        Line4Lbl = new javax.swing.JLabel();
        UpdateCarDetailsLbl = new javax.swing.JLabel();
        CarColourtxt = new javax.swing.JTextField();
        Line5Lbl = new javax.swing.JLabel();
        Mileagetxt = new javax.swing.JTextField();
        UpdateBtn = new javax.swing.JButton();
        Line1Lbl = new javax.swing.JLabel();
        Line2Lbl = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        Pricelbl = new javax.swing.JLabel();
        CarTypelbl = new javax.swing.JLabel();
        CarBrandlbl = new javax.swing.JLabel();
        CarColourlbl = new javax.swing.JLabel();
        Mileagelbl = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(441, 432));
        setUndecorated(true);

        UpdatePanel.setBackground(new java.awt.Color(255, 255, 255));
        UpdatePanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        UpdatePanel.setMaximumSize(new java.awt.Dimension(390, 393));
        UpdatePanel.setMinimumSize(new java.awt.Dimension(390, 393));
        UpdatePanel.setLayout(null);

        MileageLbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        MileageLbl.setForeground(new java.awt.Color(0, 0, 0));
        MileageLbl.setText("Mileage :");
        UpdatePanel.add(MileageLbl);
        MileageLbl.setBounds(50, 270, 150, 30);

        NoPlatelbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        NoPlatelbl.setForeground(new java.awt.Color(0, 0, 0));
        NoPlatelbl.setText("Car No Plate :");
        UpdatePanel.add(NoPlatelbl);
        NoPlatelbl.setBounds(20, 70, 120, 30);

        PriceLbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        PriceLbl.setForeground(new java.awt.Color(0, 0, 0));
        PriceLbl.setText("Price Per Hour :");
        UpdatePanel.add(PriceLbl);
        PriceLbl.setBounds(50, 310, 140, 30);

        Line3Lbl.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line3Lbl.setForeground(new java.awt.Color(0, 0, 0));
        Line3Lbl.setText("_________________________");
        Line3Lbl.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        UpdatePanel.add(Line3Lbl);
        Line3Lbl.setBounds(150, 80, 170, 16);

        Line6Lbl.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line6Lbl.setForeground(new java.awt.Color(0, 0, 0));
        Line6Lbl.setText("_________________");
        Line6Lbl.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        UpdatePanel.add(Line6Lbl);
        Line6Lbl.setBounds(200, 320, 110, 16);

        NoPlatetxt.setBackground(new java.awt.Color(255, 255, 255));
        NoPlatetxt.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        NoPlatetxt.setForeground(new java.awt.Color(0, 0, 0));
        NoPlatetxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        NoPlatetxt.setBorder(null);
        NoPlatetxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        NoPlatetxt.setSelectedTextColor(new java.awt.Color(204, 204, 204));
        UpdatePanel.add(NoPlatetxt);
        NoPlatetxt.setBounds(150, 70, 160, 30);

        Pricetxt.setBackground(new java.awt.Color(255, 255, 255));
        Pricetxt.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        Pricetxt.setForeground(new java.awt.Color(0, 0, 0));
        Pricetxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Pricetxt.setBorder(null);
        Pricetxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        Pricetxt.setSelectedTextColor(new java.awt.Color(204, 204, 204));
        UpdatePanel.add(Pricetxt);
        Pricetxt.setBounds(200, 310, 110, 30);

        CarTypeLbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        CarTypeLbl.setForeground(new java.awt.Color(0, 0, 0));
        CarTypeLbl.setText("Car Type :");
        UpdatePanel.add(CarTypeLbl);
        CarTypeLbl.setBounds(50, 150, 110, 30);

        CarTypeCB.setBackground(new java.awt.Color(255, 255, 255));
        CarTypeCB.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        CarTypeCB.setForeground(new java.awt.Color(0, 0, 0));
        CarTypeCB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Minivan", "MPV", "Sedan", "Coupe", "Pick-up", "Suv", "Hatchback" }));
        UpdatePanel.add(CarTypeCB);
        CarTypeCB.setBounds(150, 150, 130, 30);

        CarBrandLbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        CarBrandLbl.setForeground(new java.awt.Color(0, 0, 0));
        CarBrandLbl.setText("Car Brand :");
        UpdatePanel.add(CarBrandLbl);
        CarBrandLbl.setBounds(50, 190, 150, 30);

        CarBrandCB.setBackground(new java.awt.Color(255, 255, 255));
        CarBrandCB.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        CarBrandCB.setForeground(new java.awt.Color(0, 0, 0));
        CarBrandCB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Toyota", "Ford", "BMW", "Honda", "Nissan", "Mercedes-Benz", "Audi", "Mazda" }));
        UpdatePanel.add(CarBrandCB);
        CarBrandCB.setBounds(160, 190, 140, 30);

        CarColourLbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        CarColourLbl.setForeground(new java.awt.Color(0, 0, 0));
        CarColourLbl.setText("Car Colour : ");
        UpdatePanel.add(CarColourLbl);
        CarColourLbl.setBounds(50, 230, 140, 30);

        SearchBtn.setBackground(new java.awt.Color(255, 255, 255));
        SearchBtn.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        SearchBtn.setForeground(new java.awt.Color(0, 0, 0));
        SearchBtn.setText("Search");
        SearchBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchBtnMouseClicked(evt);
            }
        });
        UpdatePanel.add(SearchBtn);
        SearchBtn.setBounds(330, 70, 90, 30);

        Line4Lbl.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line4Lbl.setForeground(new java.awt.Color(0, 0, 0));
        Line4Lbl.setText("_________________________");
        Line4Lbl.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        UpdatePanel.add(Line4Lbl);
        Line4Lbl.setBounds(160, 240, 175, 16);

        UpdateCarDetailsLbl.setFont(new java.awt.Font("Rockwell", 1, 18)); // NOI18N
        UpdateCarDetailsLbl.setForeground(new java.awt.Color(0, 0, 0));
        UpdateCarDetailsLbl.setText("Update Car Details");
        UpdatePanel.add(UpdateCarDetailsLbl);
        UpdateCarDetailsLbl.setBounds(130, 10, 180, 30);

        CarColourtxt.setBackground(new java.awt.Color(255, 255, 255));
        CarColourtxt.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        CarColourtxt.setForeground(new java.awt.Color(0, 0, 0));
        CarColourtxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        CarColourtxt.setBorder(null);
        CarColourtxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        CarColourtxt.setSelectedTextColor(new java.awt.Color(204, 204, 204));
        UpdatePanel.add(CarColourtxt);
        CarColourtxt.setBounds(160, 230, 160, 30);

        Line5Lbl.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line5Lbl.setForeground(new java.awt.Color(0, 0, 0));
        Line5Lbl.setText("_____________________");
        Line5Lbl.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        UpdatePanel.add(Line5Lbl);
        Line5Lbl.setBounds(140, 280, 140, 16);

        Mileagetxt.setBackground(new java.awt.Color(255, 255, 255));
        Mileagetxt.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        Mileagetxt.setForeground(new java.awt.Color(0, 0, 0));
        Mileagetxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Mileagetxt.setBorder(null);
        Mileagetxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        Mileagetxt.setSelectedTextColor(new java.awt.Color(204, 204, 204));
        UpdatePanel.add(Mileagetxt);
        Mileagetxt.setBounds(140, 270, 130, 30);

        UpdateBtn.setBackground(new java.awt.Color(255, 255, 255));
        UpdateBtn.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        UpdateBtn.setForeground(new java.awt.Color(0, 0, 0));
        UpdateBtn.setText("Update");
        UpdateBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UpdateBtnMouseClicked(evt);
            }
        });
        UpdatePanel.add(UpdateBtn);
        UpdateBtn.setBounds(150, 370, 120, 40);

        Line1Lbl.setBackground(new java.awt.Color(0, 0, 0));
        Line1Lbl.setFont(new java.awt.Font("DialogInput", 1, 12)); // NOI18N
        Line1Lbl.setForeground(new java.awt.Color(0, 0, 0));
        Line1Lbl.setText("_____________________________________________________________");
        UpdatePanel.add(Line1Lbl);
        Line1Lbl.setBounds(0, 40, 450, 17);

        Line2Lbl.setBackground(new java.awt.Color(0, 0, 0));
        Line2Lbl.setFont(new java.awt.Font("DialogInput", 1, 12)); // NOI18N
        Line2Lbl.setForeground(new java.awt.Color(0, 0, 0));
        Line2Lbl.setText("_____________________________________________________________");
        UpdatePanel.add(Line2Lbl);
        Line2Lbl.setBounds(0, 100, 450, 17);

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Cancel");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        UpdatePanel.add(jButton1);
        jButton1.setBounds(350, 390, 68, 24);

        Pricelbl.setBackground(new java.awt.Color(51, 51, 51));
        Pricelbl.setFont(new java.awt.Font("Rockwell", 2, 14)); // NOI18N
        Pricelbl.setForeground(new java.awt.Color(51, 51, 51));
        UpdatePanel.add(Pricelbl);
        Pricelbl.setBounds(320, 320, 80, 15);

        CarTypelbl.setBackground(new java.awt.Color(51, 51, 51));
        CarTypelbl.setFont(new java.awt.Font("Rockwell", 2, 14)); // NOI18N
        CarTypelbl.setForeground(new java.awt.Color(51, 51, 51));
        UpdatePanel.add(CarTypelbl);
        CarTypelbl.setBounds(290, 160, 90, 15);

        CarBrandlbl.setBackground(new java.awt.Color(51, 51, 51));
        CarBrandlbl.setFont(new java.awt.Font("Rockwell", 2, 14)); // NOI18N
        CarBrandlbl.setForeground(new java.awt.Color(51, 51, 51));
        UpdatePanel.add(CarBrandlbl);
        CarBrandlbl.setBounds(310, 200, 80, 15);

        CarColourlbl.setBackground(new java.awt.Color(51, 51, 51));
        CarColourlbl.setFont(new java.awt.Font("Rockwell", 2, 14)); // NOI18N
        CarColourlbl.setForeground(new java.awt.Color(51, 51, 51));
        UpdatePanel.add(CarColourlbl);
        CarColourlbl.setBounds(330, 240, 80, 15);

        Mileagelbl.setBackground(new java.awt.Color(51, 51, 51));
        Mileagelbl.setFont(new java.awt.Font("Rockwell", 2, 14)); // NOI18N
        Mileagelbl.setForeground(new java.awt.Color(51, 51, 51));
        UpdatePanel.add(Mileagelbl);
        Mileagelbl.setBounds(280, 280, 90, 15);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(UpdatePanel, javax.swing.GroupLayout.DEFAULT_SIZE, 441, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(UpdatePanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 432, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SearchBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchBtnMouseClicked
        String search_noplate = NoPlatetxt.getText();
        if (search_noplate.isEmpty()) {
            JOptionPane.showMessageDialog(this, "enter no plate to search");
        } else {
            String []records;
            String line;
            try (BufferedReader reader = new BufferedReader(new FileReader("Cars.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String NoPlate = (records[0]) ;
                String CarType = (records[1]) ;
                String CarBrand= (records[2]) ;
                String CarColour = (records[3]);
                String Mileage = (records[4]);
                String Price = (records[5]);
                if (NoPlate.equals(search_noplate)) {
                        CarTypelbl.setText(CarType);
                        CarBrandlbl.setText(CarBrand);
                        CarColourlbl.setText(CarColour);
                        Mileagelbl.setText(Mileage);
                        Pricelbl.setText(Price);
                        return;
                    }
                }
                JOptionPane.showMessageDialog(this, "Car not found");
            } catch (FileNotFoundException ex) {
            } catch (IOException ex) {
            }
        }
    }//GEN-LAST:event_SearchBtnMouseClicked

    private void UpdateBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdateBtnMouseClicked
        String search_noplate = NoPlatetxt.getText();
        String CarType = CarTypeCB.getSelectedItem().toString();
        String CarBrand = CarBrandCB.getSelectedItem().toString();
        String CarColour = CarColourtxt.getText();
        String Mileage = Mileagetxt.getText();
        String Price = Pricetxt.getText();
        CarDetails.UpdateCar(search_noplate,CarType,CarBrand,CarColour,Mileage,Price);
        JOptionPane.showMessageDialog(null,"Car Details Updated Successfully");
        NoPlatetxt.setText("");
        CarColourtxt.setText("");
        Mileagetxt.setText("");
        Pricetxt.setText("");
        CarTypelbl.setText("");
        CarBrandlbl.setText("");
        CarColourlbl.setText("");
        Mileagelbl.setText("");
        Pricelbl.setText("");
    }//GEN-LAST:event_UpdateBtnMouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        dispose();
    }//GEN-LAST:event_jButton1MouseClicked

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdBtnOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdBtnOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdBtnOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdBtnOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdBtnOption().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CarBrandCB;
    private javax.swing.JLabel CarBrandLbl;
    private javax.swing.JLabel CarBrandlbl;
    private javax.swing.JLabel CarColourLbl;
    private javax.swing.JLabel CarColourlbl;
    private javax.swing.JTextField CarColourtxt;
    private javax.swing.JComboBox<String> CarTypeCB;
    private javax.swing.JLabel CarTypeLbl;
    private javax.swing.JLabel CarTypelbl;
    private javax.swing.JLabel Line1Lbl;
    private javax.swing.JLabel Line2Lbl;
    private javax.swing.JLabel Line3Lbl;
    private javax.swing.JLabel Line4Lbl;
    private javax.swing.JLabel Line5Lbl;
    private javax.swing.JLabel Line6Lbl;
    private javax.swing.JLabel MileageLbl;
    private javax.swing.JLabel Mileagelbl;
    private javax.swing.JTextField Mileagetxt;
    private javax.swing.JLabel NoPlatelbl;
    private javax.swing.JTextField NoPlatetxt;
    private javax.swing.JLabel PriceLbl;
    private javax.swing.JLabel Pricelbl;
    private javax.swing.JTextField Pricetxt;
    private javax.swing.JButton SearchBtn;
    private javax.swing.JButton UpdateBtn;
    private javax.swing.JLabel UpdateCarDetailsLbl;
    private javax.swing.JPanel UpdatePanel;
    private javax.swing.JButton jButton1;
    // End of variables declaration//GEN-END:variables
}
