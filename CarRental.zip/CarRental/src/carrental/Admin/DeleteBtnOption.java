/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package carrental.Admin;

import Carrental.Admin.CarDetails;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JOptionPane;


public class DeleteBtnOption extends javax.swing.JFrame {

    public DeleteBtnOption() {
        initComponents();
        Toolkit toolkit= getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2); 
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        DeletePanel = new javax.swing.JPanel();
        CarNoPlatelbl = new javax.swing.JLabel();
        DeleteCarDetailsllbl = new javax.swing.JLabel();
        Line1 = new javax.swing.JLabel();
        NoPlatetxt = new javax.swing.JTextField();
        DeleteBtn = new javax.swing.JButton();
        Cancel = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(337, 349));
        setUndecorated(true);

        DeletePanel.setBackground(new java.awt.Color(255, 255, 255));
        DeletePanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        DeletePanel.setMaximumSize(new java.awt.Dimension(337, 349));
        DeletePanel.setMinimumSize(new java.awt.Dimension(337, 349));
        DeletePanel.setLayout(null);

        CarNoPlatelbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        CarNoPlatelbl.setForeground(new java.awt.Color(0, 0, 0));
        CarNoPlatelbl.setText("Car No Plate");
        DeletePanel.add(CarNoPlatelbl);
        CarNoPlatelbl.setBounds(120, 100, 110, 30);

        DeleteCarDetailsllbl.setFont(new java.awt.Font("Rockwell", 1, 18)); // NOI18N
        DeleteCarDetailsllbl.setForeground(new java.awt.Color(0, 0, 0));
        DeleteCarDetailsllbl.setText("Delete Car Details");
        DeletePanel.add(DeleteCarDetailsllbl);
        DeleteCarDetailsllbl.setBounds(90, 30, 180, 30);

        Line1.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line1.setForeground(new java.awt.Color(0, 0, 0));
        Line1.setText("_________________________");
        Line1.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        DeletePanel.add(Line1);
        Line1.setBounds(90, 160, 170, 16);

        NoPlatetxt.setBackground(new java.awt.Color(255, 255, 255));
        NoPlatetxt.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        NoPlatetxt.setForeground(new java.awt.Color(0, 0, 0));
        NoPlatetxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        NoPlatetxt.setBorder(null);
        NoPlatetxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        NoPlatetxt.setSelectedTextColor(new java.awt.Color(204, 204, 204));
        NoPlatetxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NoPlatetxtActionPerformed(evt);
            }
        });
        DeletePanel.add(NoPlatetxt);
        NoPlatetxt.setBounds(90, 140, 160, 30);

        DeleteBtn.setBackground(new java.awt.Color(255, 255, 255));
        DeleteBtn.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        DeleteBtn.setForeground(new java.awt.Color(0, 0, 0));
        DeleteBtn.setText("Delete");
        DeleteBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DeleteBtnMouseClicked(evt);
            }
        });
        DeletePanel.add(DeleteBtn);
        DeleteBtn.setBounds(120, 190, 100, 30);

        Cancel.setBackground(new java.awt.Color(0, 0, 0));
        Cancel.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        Cancel.setForeground(new java.awt.Color(255, 255, 255));
        Cancel.setText("Cancel");
        Cancel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CancelMouseClicked(evt);
            }
        });
        DeletePanel.add(Cancel);
        Cancel.setBounds(250, 310, 70, 24);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(DeletePanel, javax.swing.GroupLayout.DEFAULT_SIZE, 337, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(DeletePanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 349, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NoPlatetxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NoPlatetxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NoPlatetxtActionPerformed

    private void DeleteBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeleteBtnMouseClicked
        String NoPlate = NoPlatetxt.getText();
        if (NoPlate.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter Car No Plate to search");
        } else {
            CarDetails.delete(NoPlate);
            JOptionPane.showMessageDialog(null, "Car Removed Succesfully");
            NoPlatetxt.setText("");
        }
    }//GEN-LAST:event_DeleteBtnMouseClicked

    private void CancelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CancelMouseClicked
        dispose();
    }//GEN-LAST:event_CancelMouseClicked

    
    public static void main(String args[]) {
       
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DeleteBtnOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DeleteBtnOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DeleteBtnOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DeleteBtnOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DeleteBtnOption().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cancel;
    private javax.swing.JLabel CarNoPlatelbl;
    private javax.swing.JButton DeleteBtn;
    private javax.swing.JLabel DeleteCarDetailsllbl;
    private javax.swing.JPanel DeletePanel;
    private javax.swing.JLabel Line1;
    private javax.swing.JTextField NoPlatetxt;
    // End of variables declaration//GEN-END:variables
}
