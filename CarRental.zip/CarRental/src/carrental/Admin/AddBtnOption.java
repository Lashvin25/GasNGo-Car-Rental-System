/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package carrental.Admin;

import Carrental.Admin.CarDetails;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JOptionPane;

/**
 *
 * @author Lashvin
 */
public class AddBtnOption extends javax.swing.JFrame {

    /**
     * Creates new form AddBtnOption
     */
    public AddBtnOption() {
        initComponents();
        Toolkit toolkit= getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        AddPanel = new javax.swing.JPanel();
        CarNoPlateLbl = new javax.swing.JLabel();
        Linelbl1 = new javax.swing.JLabel();
        NoPlatetxt = new javax.swing.JTextField();
        CarTypeLbl = new javax.swing.JLabel();
        CarBrandLbl = new javax.swing.JLabel();
        CarColourLabel = new javax.swing.JLabel();
        Linelbl2 = new javax.swing.JLabel();
        CarColourtxt = new javax.swing.JTextField();
        Linelbl4 = new javax.swing.JLabel();
        Mileagetxt = new javax.swing.JTextField();
        MileageLbl = new javax.swing.JLabel();
        PriceLbl = new javax.swing.JLabel();
        Linelbl5 = new javax.swing.JLabel();
        Pricetxt = new javax.swing.JTextField();
        CarTypeCB = new javax.swing.JComboBox<>();
        CarBrandCB = new javax.swing.JComboBox<>();
        AddBtn = new javax.swing.JButton();
        AddCarLbl = new javax.swing.JLabel();
        CancelBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(413, 414));
        setUndecorated(true);

        AddPanel.setBackground(new java.awt.Color(255, 255, 255));
        AddPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        AddPanel.setMaximumSize(new java.awt.Dimension(413, 414));
        AddPanel.setMinimumSize(new java.awt.Dimension(413, 414));
        AddPanel.setPreferredSize(new java.awt.Dimension(413, 414));
        AddPanel.setLayout(null);

        CarNoPlateLbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        CarNoPlateLbl.setForeground(new java.awt.Color(0, 0, 0));
        CarNoPlateLbl.setText("Car No Plate :");
        AddPanel.add(CarNoPlateLbl);
        CarNoPlateLbl.setBounds(58, 78, 120, 30);

        Linelbl1.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Linelbl1.setForeground(new java.awt.Color(0, 0, 0));
        Linelbl1.setText("_________________________");
        Linelbl1.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        AddPanel.add(Linelbl1);
        Linelbl1.setBounds(188, 88, 170, 16);

        NoPlatetxt.setBackground(new java.awt.Color(255, 255, 255));
        NoPlatetxt.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        NoPlatetxt.setForeground(new java.awt.Color(0, 0, 0));
        NoPlatetxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        NoPlatetxt.setBorder(null);
        NoPlatetxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        NoPlatetxt.setSelectedTextColor(new java.awt.Color(204, 204, 204));
        AddPanel.add(NoPlatetxt);
        NoPlatetxt.setBounds(188, 78, 160, 30);

        CarTypeLbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        CarTypeLbl.setForeground(new java.awt.Color(0, 0, 0));
        CarTypeLbl.setText("Car Type :");
        AddPanel.add(CarTypeLbl);
        CarTypeLbl.setBounds(58, 118, 110, 30);

        CarBrandLbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        CarBrandLbl.setForeground(new java.awt.Color(0, 0, 0));
        CarBrandLbl.setText("Car Brand :");
        AddPanel.add(CarBrandLbl);
        CarBrandLbl.setBounds(58, 158, 150, 30);

        CarColourLabel.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        CarColourLabel.setForeground(new java.awt.Color(0, 0, 0));
        CarColourLabel.setText("Car Colour : ");
        AddPanel.add(CarColourLabel);
        CarColourLabel.setBounds(58, 198, 140, 30);

        Linelbl2.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Linelbl2.setForeground(new java.awt.Color(0, 0, 0));
        Linelbl2.setText("_________________________");
        Linelbl2.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        AddPanel.add(Linelbl2);
        Linelbl2.setBounds(168, 208, 175, 16);

        CarColourtxt.setBackground(new java.awt.Color(255, 255, 255));
        CarColourtxt.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        CarColourtxt.setForeground(new java.awt.Color(0, 0, 0));
        CarColourtxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        CarColourtxt.setBorder(null);
        CarColourtxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        CarColourtxt.setSelectedTextColor(new java.awt.Color(204, 204, 204));
        AddPanel.add(CarColourtxt);
        CarColourtxt.setBounds(168, 198, 160, 30);

        Linelbl4.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Linelbl4.setForeground(new java.awt.Color(0, 0, 0));
        Linelbl4.setText("_________________________");
        Linelbl4.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        AddPanel.add(Linelbl4);
        Linelbl4.setBounds(148, 248, 200, 16);

        Mileagetxt.setBackground(new java.awt.Color(255, 255, 255));
        Mileagetxt.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        Mileagetxt.setForeground(new java.awt.Color(0, 0, 0));
        Mileagetxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Mileagetxt.setBorder(null);
        Mileagetxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        Mileagetxt.setSelectedTextColor(new java.awt.Color(204, 204, 204));
        AddPanel.add(Mileagetxt);
        Mileagetxt.setBounds(148, 238, 160, 22);

        MileageLbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        MileageLbl.setForeground(new java.awt.Color(0, 0, 0));
        MileageLbl.setText("Mileage :");
        AddPanel.add(MileageLbl);
        MileageLbl.setBounds(58, 238, 150, 30);

        PriceLbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        PriceLbl.setForeground(new java.awt.Color(0, 0, 0));
        PriceLbl.setText("Price Per Hour :");
        AddPanel.add(PriceLbl);
        PriceLbl.setBounds(58, 278, 140, 30);

        Linelbl5.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Linelbl5.setForeground(new java.awt.Color(0, 0, 0));
        Linelbl5.setText("_________________________");
        Linelbl5.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        AddPanel.add(Linelbl5);
        Linelbl5.setBounds(208, 288, 170, 16);

        Pricetxt.setBackground(new java.awt.Color(255, 255, 255));
        Pricetxt.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        Pricetxt.setForeground(new java.awt.Color(0, 0, 0));
        Pricetxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Pricetxt.setBorder(null);
        Pricetxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        Pricetxt.setSelectedTextColor(new java.awt.Color(204, 204, 204));
        AddPanel.add(Pricetxt);
        Pricetxt.setBounds(208, 278, 160, 30);

        CarTypeCB.setBackground(new java.awt.Color(255, 255, 255));
        CarTypeCB.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        CarTypeCB.setForeground(new java.awt.Color(0, 0, 0));
        CarTypeCB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Minivan", "MPV", "Sedan", "Coupe", "Pick-up", "Suv", "Hatchback" }));
        AddPanel.add(CarTypeCB);
        CarTypeCB.setBounds(158, 118, 130, 30);

        CarBrandCB.setBackground(new java.awt.Color(255, 255, 255));
        CarBrandCB.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        CarBrandCB.setForeground(new java.awt.Color(0, 0, 0));
        CarBrandCB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Toyota", "Ford", "BMW", "Honda", "Nissan", "Mercedes-Benz", "Audi", "Mazda" }));
        AddPanel.add(CarBrandCB);
        CarBrandCB.setBounds(178, 158, 140, 30);

        AddBtn.setBackground(new java.awt.Color(255, 255, 255));
        AddBtn.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        AddBtn.setForeground(new java.awt.Color(0, 0, 0));
        AddBtn.setText("ADD");
        AddBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddBtnMouseClicked(evt);
            }
        });
        AddPanel.add(AddBtn);
        AddBtn.setBounds(138, 342, 120, 40);

        AddCarLbl.setFont(new java.awt.Font("Rockwell", 1, 18)); // NOI18N
        AddCarLbl.setForeground(new java.awt.Color(0, 0, 0));
        AddCarLbl.setText("Add Car Details");
        AddPanel.add(AddCarLbl);
        AddCarLbl.setBounds(127, 21, 204, 30);

        CancelBtn.setBackground(new java.awt.Color(0, 0, 0));
        CancelBtn.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        CancelBtn.setForeground(new java.awt.Color(255, 255, 255));
        CancelBtn.setText("Cancel");
        CancelBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CancelBtnMouseClicked(evt);
            }
        });
        AddPanel.add(CancelBtn);
        CancelBtn.setBounds(320, 370, 70, 24);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(AddPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 429, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(AddPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CancelBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CancelBtnMouseClicked
        dispose();
    }//GEN-LAST:event_CancelBtnMouseClicked

    private void AddBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddBtnMouseClicked
        String NoPlate = NoPlatetxt.getText();
        String CarType = CarTypeCB.getSelectedItem().toString();
        String CarBrand = CarBrandCB.getSelectedItem().toString();
        String CarColour = CarColourtxt.getText();
        String Mileage = Mileagetxt.getText();
        String Price = Pricetxt.getText();
        
        CarDetails Car = new CarDetails(NoPlate,CarType,CarBrand,CarColour,Mileage,Price);
        Car.AddCar();
        JOptionPane.showMessageDialog(null,"Car Details Added Successfully");
        
        NoPlatetxt.setText("");
        CarColourtxt.setText("");
        Mileagetxt.setText("");
        Pricetxt.setText("");
        
    }//GEN-LAST:event_AddBtnMouseClicked
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddBtnOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddBtnOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddBtnOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddBtnOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddBtnOption().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddBtn;
    private javax.swing.JLabel AddCarLbl;
    private javax.swing.JPanel AddPanel;
    private javax.swing.JButton CancelBtn;
    private javax.swing.JComboBox<String> CarBrandCB;
    private javax.swing.JLabel CarBrandLbl;
    private javax.swing.JLabel CarColourLabel;
    private javax.swing.JTextField CarColourtxt;
    private javax.swing.JLabel CarNoPlateLbl;
    private javax.swing.JComboBox<String> CarTypeCB;
    private javax.swing.JLabel CarTypeLbl;
    private javax.swing.JLabel Linelbl1;
    private javax.swing.JLabel Linelbl2;
    private javax.swing.JLabel Linelbl4;
    private javax.swing.JLabel Linelbl5;
    private javax.swing.JLabel MileageLbl;
    private javax.swing.JTextField Mileagetxt;
    private javax.swing.JTextField NoPlatetxt;
    private javax.swing.JLabel PriceLbl;
    private javax.swing.JTextField Pricetxt;
    // End of variables declaration//GEN-END:variables
}
