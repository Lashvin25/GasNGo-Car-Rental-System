/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CarRental.Superuser;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Lashvin
 */
public class Superuser {
    String AdmName;
    String AdmICNum;
    String AdmPNum;
    String AdmEAdd;
    String AdmHAdd;
    String AdmUN;
    String AdmPass;
    String AdmSW;
    
    public Superuser(String AdmName,String AdmICNum,String AdmPNum,String AdmEAdd,String AdmHAdd,String AdmUN,String AdmPass,String AdmSW){
        this.AdmName = AdmName;
        this.AdmICNum = AdmICNum;
        this.AdmPNum = AdmPNum;
        this.AdmEAdd = AdmEAdd;
        this.AdmHAdd = AdmHAdd;
        this.AdmUN = AdmUN;
        this.AdmPass = AdmPass;
        this.AdmSW = AdmSW;
    }
    public void AddAdmin(){
        try{
            BufferedWriter BW = new BufferedWriter (new FileWriter(("Admin.txt"),true));
            BW.write(AdmName + ":" + AdmICNum + ":" + AdmPNum + ":" + AdmEAdd + ":" + AdmHAdd +":"+ AdmUN + ":" + AdmPass + ":" + AdmSW + ":" + "Admin");
            BW.newLine();
            BW.close();
            BufferedWriter U = new BufferedWriter (new FileWriter(("User.txt"),true));
            U.write( AdmUN + ":" + AdmPass + ":" + AdmSW + ":" + "Admin" );
            U.newLine();
            U.close();
            JOptionPane.showMessageDialog(null,"Car Details Added Successfully");
        }catch(IOException e){}
    }
    public static void delete(String AdminUsername){
        
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("Admin.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String AdmName  = (records[0]);
                String AdmICNum = (records[1]);
                String AdmPNum = (records[2]);
                String AdmEAdd = (records[3]);
                String AdmHAdd = (records[4]);
                String AdmUN = (records[5]);
                String AdmPass = (records[6]);
                String AdmSW = (records[7]);
                String AdmRole = (records[8]);
                if (!AdminUsername.equals(AdmUN)){
                    modifyArray.add(AdmName + ":" + AdmICNum + ":" + AdmPNum + ":" + AdmEAdd + ":" + AdmHAdd  +":"+ AdmUN + ":" + AdmPass + ":" + AdmSW + ":" + AdmRole);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("Admin.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Admin details");
        }
    }
    
    public static void delete1(String AdminUsername){
        
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("User.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String AdmUN = (records[0]);
                String AdmPass = (records[1]);
                String AdmSW = (records[2]);
                String AdmRole = (records[3]);
                if (!AdminUsername.equals(records[0])){
                    modifyArray.add(AdmUN + ":" + AdmPass + ":" + AdmSW + ":" + AdmRole);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("User.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Admin details");
        }
    }
    
    public static void update(String AdminUsername, String AdminPass, String AdminPN, String AdminEA, String AdminHA){
        
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("Admin.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String AdmName  = (records[0]);
                String AdmICNum = (records[1]);
                String AdmUN = (records[5]);
                String AdmSW = (records[7]);
                if (AdminUsername.equals(records[5])){
                    modifyArray.add(AdmName + ":" + AdmICNum + ":" + AdminPN + ":" + AdminEA + ":" + AdminHA  +":"+ AdmUN + ":" + AdminPass + ":" + AdmSW + ":" + "Admin");
                }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("Admin.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Admin details");
        }
    }
    
    public static void update1(String AdminUsername, String AdminPass){
        
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("User.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String AdmUN = (records[0]);
                String AdmSW = (records[2]);
                String AdmRole = (records[3]);
                if (AdminUsername.equals(records[0])){
                    modifyArray.add(AdmUN + ":" + AdminPass + ":" + AdmSW + ":" + AdmRole);
                }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("User.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Admin details");
        }
    }
    public static void AdminUpdatePassword(String Username,String NewPassword){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("Admin.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String AdmName  = (records[0]);
                String AdmICNum = (records[1]);
                String AdmPNum = (records[2]);
                String AdmEAdd = (records[3]);
                String AdmHAdd = (records[4]);
                String AdmUN = (records[5]);
                String AdmSW = (records[7]);
                String AdmRole = (records[8]);
                if (Username.equals(AdmUN)){
                    modifyArray.add(AdmName + ":" + AdmICNum + ":" + AdmPNum + ":" + AdmEAdd + ":" + AdmHAdd +":"+ AdmUN + ":" + NewPassword + ":" + AdmSW + ":" + AdmRole);
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("Admin.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
    
    public static void UserUpdatePassword(String Username,String NewPassword){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("User.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String UserName = (records[0]);
                String OldPassword = (records[1]);
                String Secureword = (records[2]);
                String UserRole = (records[3]);
                if (Username.equals(UserName)){
                    modifyArray.add(UserName + ":" + NewPassword + ":" + Secureword + ":" + UserRole );
                    JOptionPane.showMessageDialog(null,"Your Password has been changed succesfully");
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("User.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
    
    public static void AdminProfileUpdate(String AdminUsername,String N,String IC,String PN,String EA,String UN,String HA,String SW){
        
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("Admin.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String AdmUN = (records[5]);
                String AdminPass = (records[6]);
                String UserRole = (records[7]);
                if (AdminUsername.equals(AdmUN)){
                    modifyArray.add(N + ":" + IC + ":" + PN + ":" + EA + ":" + HA 
                            +":"+ UN + ":" + AdminPass + ":" + SW + ":" + UserRole);
                }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("Admin.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Admin details");
        }
    }
    
    public static void AdminProfileUpdateUser(String AdminUsername,String UN,String SW){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("User.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String UserName = (records[0]);
                String OldPassword = (records[1]);
                String UserRole = (records[3]);
                if (AdminUsername.equals(UserName)){
                    modifyArray.add(UN + ":" + OldPassword + ":" + SW + ":" + UserRole );
                    JOptionPane.showMessageDialog(null,"Your Profile has been update succesfully");
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("User.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
    
    

}

        
    


