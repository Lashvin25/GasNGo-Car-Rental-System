/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package CarRental.Superuser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Lashvin
 */
public class ManageAdmin extends javax.swing.JInternalFrame {

    public ManageAdmin() {
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI)this.getUI();
        ui.setNorthPane(null);
        DisplayAdmin();
        HideEdit();
    }
    
    public void DisplayAdmin(){
        String FilePath = "Admin.txt";
            File AdminDetails = new File(FilePath);
            
            try{
                BufferedReader Add = new BufferedReader(new FileReader(AdminDetails));
                DefaultTableModel model = (DefaultTableModel)AdminDetailsTable.getModel();
                Object[] Lines = Add.lines().toArray();
                for(int i=0; i < Lines.length; i++){
                    String Line = Lines[i].toString().trim();
                    String[] dataRow = Line.split(":");
                    
                    model.addRow(dataRow);
                }
                Add.close();
            }catch (IOException ex){
                
            }
    }
    
    public void HideEdit(){
        unlbl.setVisible(false);
        passlbl.setVisible(false);
        phonenumlbl.setVisible(false);
        emaddlbl.setVisible(false);
        houseaddlbl.setVisible(false);
        untxt.setVisible(false);
        passtxt.setVisible(false);
        PhoneNumtxt.setVisible(false);
        emaddtxt.setVisible(false);
        houseaddtxt.setVisible(false);
        UNline.setVisible(false);
        Passline.setVisible(false);
        PNline.setVisible(false);
        EAline.setVisible(false);
        HAline.setVisible(false);
        ConfirmBtn.setVisible(false);
        CancelBtn.setVisible(false);
        
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        AdminDetailsTable = new javax.swing.JTable();
        passlbl = new javax.swing.JLabel();
        Passline = new javax.swing.JLabel();
        passtxt = new javax.swing.JTextField();
        UNline = new javax.swing.JLabel();
        unlbl = new javax.swing.JLabel();
        EAline = new javax.swing.JLabel();
        emaddtxt = new javax.swing.JTextField();
        PNline = new javax.swing.JLabel();
        PhoneNumtxt = new javax.swing.JTextField();
        phonenumlbl = new javax.swing.JLabel();
        emaddlbl = new javax.swing.JLabel();
        HAline = new javax.swing.JLabel();
        houseaddtxt = new javax.swing.JTextField();
        houseaddlbl = new javax.swing.JLabel();
        untxt1 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        EditBtn = new javax.swing.JButton();
        ConfirmBtn = new javax.swing.JButton();
        DeleteBtn = new javax.swing.JButton();
        AdminDetailslbl = new javax.swing.JLabel();
        CancelBtn = new javax.swing.JButton();
        untxt = new javax.swing.JLabel();

        setMaximumSize(new java.awt.Dimension(770, 550));
        setMinimumSize(new java.awt.Dimension(770, 550));
        setPreferredSize(new java.awt.Dimension(790, 570));
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(770, 550));
        jPanel1.setPreferredSize(new java.awt.Dimension(770, 550));
        jPanel1.setLayout(null);

        AdminDetailsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "IC Number", "Phone Number", "Email", "Address", "Username", "Password", "SecureWord"
            }
        ));
        AdminDetailsTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AdminDetailsTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(AdminDetailsTable);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(10, 50, 750, 270);

        passlbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        passlbl.setForeground(new java.awt.Color(0, 0, 0));
        passlbl.setText("Password : ");
        jPanel1.add(passlbl);
        passlbl.setBounds(20, 410, 100, 30);

        Passline.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Passline.setForeground(new java.awt.Color(0, 0, 0));
        Passline.setText("________________________");
        Passline.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel1.add(Passline);
        Passline.setBounds(130, 420, 160, 16);

        passtxt.setBackground(new java.awt.Color(255, 255, 255));
        passtxt.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        passtxt.setForeground(new java.awt.Color(0, 0, 0));
        passtxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        passtxt.setBorder(null);
        passtxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        passtxt.setSelectedTextColor(new java.awt.Color(204, 204, 204));
        jPanel1.add(passtxt);
        passtxt.setBounds(130, 410, 160, 30);

        UNline.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        UNline.setForeground(new java.awt.Color(0, 0, 0));
        UNline.setText("________________________");
        UNline.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel1.add(UNline);
        UNline.setBounds(130, 390, 160, 16);

        unlbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        unlbl.setForeground(new java.awt.Color(0, 0, 0));
        unlbl.setText("Username : ");
        jPanel1.add(unlbl);
        unlbl.setBounds(20, 380, 110, 30);

        EAline.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        EAline.setForeground(new java.awt.Color(0, 0, 0));
        EAline.setText("_______________________________________");
        EAline.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel1.add(EAline);
        EAline.setBounds(170, 480, 250, 16);

        emaddtxt.setBackground(new java.awt.Color(255, 255, 255));
        emaddtxt.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        emaddtxt.setForeground(new java.awt.Color(0, 0, 0));
        emaddtxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        emaddtxt.setBorder(null);
        emaddtxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        emaddtxt.setSelectedTextColor(new java.awt.Color(204, 204, 204));
        jPanel1.add(emaddtxt);
        emaddtxt.setBounds(170, 470, 250, 30);

        PNline.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        PNline.setForeground(new java.awt.Color(0, 0, 0));
        PNline.setText("_________________________");
        PNline.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel1.add(PNline);
        PNline.setBounds(170, 450, 200, 16);

        PhoneNumtxt.setBackground(new java.awt.Color(255, 255, 255));
        PhoneNumtxt.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        PhoneNumtxt.setForeground(new java.awt.Color(0, 0, 0));
        PhoneNumtxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PhoneNumtxt.setBorder(null);
        PhoneNumtxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        PhoneNumtxt.setSelectedTextColor(new java.awt.Color(204, 204, 204));
        jPanel1.add(PhoneNumtxt);
        PhoneNumtxt.setBounds(170, 440, 160, 30);

        phonenumlbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        phonenumlbl.setForeground(new java.awt.Color(0, 0, 0));
        phonenumlbl.setText("Phone Number : ");
        jPanel1.add(phonenumlbl);
        phonenumlbl.setBounds(20, 440, 150, 30);

        emaddlbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        emaddlbl.setForeground(new java.awt.Color(0, 0, 0));
        emaddlbl.setText("Email Address : ");
        jPanel1.add(emaddlbl);
        emaddlbl.setBounds(20, 470, 140, 30);

        HAline.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        HAline.setForeground(new java.awt.Color(0, 0, 0));
        HAline.setText("___________________________________________________________");
        HAline.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel1.add(HAline);
        HAline.setBounds(170, 510, 380, 16);

        houseaddtxt.setBackground(new java.awt.Color(255, 255, 255));
        houseaddtxt.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        houseaddtxt.setForeground(new java.awt.Color(0, 0, 0));
        houseaddtxt.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        houseaddtxt.setBorder(null);
        houseaddtxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        houseaddtxt.setSelectedTextColor(new java.awt.Color(204, 204, 204));
        jPanel1.add(houseaddtxt);
        houseaddtxt.setBounds(170, 500, 380, 30);

        houseaddlbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        houseaddlbl.setForeground(new java.awt.Color(0, 0, 0));
        houseaddlbl.setText("House Address : ");
        jPanel1.add(houseaddlbl);
        houseaddlbl.setBounds(20, 500, 150, 30);

        untxt1.setBackground(new java.awt.Color(255, 255, 255));
        untxt1.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        untxt1.setForeground(new java.awt.Color(0, 0, 0));
        untxt1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        untxt1.setBorder(null);
        untxt1.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        untxt1.setSelectedTextColor(new java.awt.Color(204, 204, 204));
        jPanel1.add(untxt1);
        untxt1.setBounds(130, 50, 160, 30);

        jLabel16.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 0, 0));
        jLabel16.setText("________________________");
        jLabel16.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel1.add(jLabel16);
        jLabel16.setBounds(130, 60, 160, 16);

        EditBtn.setText("Edit");
        EditBtn.setBorder(null);
        EditBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EditBtnMouseClicked(evt);
            }
        });
        jPanel1.add(EditBtn);
        EditBtn.setBounds(30, 340, 130, 30);

        ConfirmBtn.setText("Confirm");
        ConfirmBtn.setBorder(null);
        ConfirmBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ConfirmBtnMouseClicked(evt);
            }
        });
        jPanel1.add(ConfirmBtn);
        ConfirmBtn.setBounds(600, 490, 130, 30);

        DeleteBtn.setText("Remove");
        DeleteBtn.setBorder(null);
        DeleteBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DeleteBtnMouseClicked(evt);
            }
        });
        DeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteBtnActionPerformed(evt);
            }
        });
        jPanel1.add(DeleteBtn);
        DeleteBtn.setBounds(190, 340, 130, 30);

        AdminDetailslbl.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        AdminDetailslbl.setForeground(new java.awt.Color(0, 0, 0));
        AdminDetailslbl.setText("ALL ADMIN DETAILS");
        jPanel1.add(AdminDetailslbl);
        AdminDetailslbl.setBounds(280, 10, 180, 30);

        CancelBtn.setText("Cancel");
        CancelBtn.setBorder(null);
        CancelBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CancelBtnMouseClicked(evt);
            }
        });
        jPanel1.add(CancelBtn);
        CancelBtn.setBounds(600, 450, 130, 30);

        untxt.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        untxt.setForeground(new java.awt.Color(0, 0, 0));
        untxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel1.add(untxt);
        untxt.setBounds(130, 380, 150, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 770, 560);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AdminDetailsTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AdminDetailsTableMouseClicked
        int selectedRow = AdminDetailsTable.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)AdminDetailsTable.getModel();
        untxt.setText(model.getValueAt(selectedRow,6).toString());
        passtxt.setText(model.getValueAt(selectedRow,7).toString());
        PhoneNumtxt.setText(model.getValueAt(selectedRow,2).toString());
        emaddtxt.setText(model.getValueAt(selectedRow,3).toString());
        houseaddtxt.setText(model.getValueAt(selectedRow,4).toString());
        
    }//GEN-LAST:event_AdminDetailsTableMouseClicked

    private void EditBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EditBtnMouseClicked
        unlbl.setVisible(true);
        passlbl.setVisible(true);
        phonenumlbl.setVisible(true);
        emaddlbl.setVisible(true);
        houseaddlbl.setVisible(true);
        untxt.setVisible(true);
        passtxt.setVisible(true);
        PhoneNumtxt.setVisible(true);
        emaddtxt.setVisible(true);
        houseaddtxt.setVisible(true);
        UNline.setVisible(true);
        Passline.setVisible(true);
        PNline.setVisible(true);
        EAline.setVisible(true);
        HAline.setVisible(true);
        ConfirmBtn.setVisible(true);
        DeleteBtn.setVisible(false);
        CancelBtn.setVisible(true);
    }//GEN-LAST:event_EditBtnMouseClicked

    private void ConfirmBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ConfirmBtnMouseClicked
       int i = AdminDetailsTable.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)AdminDetailsTable.getModel();
       if(i >=0){
           model.setValueAt(untxt.getText(),i,6);
           model.setValueAt(passtxt.getText(),i,7);
           model.setValueAt(PhoneNumtxt.getText(),i,3);
           model.setValueAt(emaddtxt.getText(),i,4);
           model.setValueAt(houseaddtxt.getText(),i,5);
           String AdminUsername = untxt.getText(); 
           String AdminPass = passtxt.getText(); 
           String AdminPN = PhoneNumtxt.getText(); 
           String AdminEA = emaddtxt.getText(); 
           String AdminHA = houseaddtxt.getText();
           
           Superuser.update(AdminUsername,AdminPass,AdminPN,AdminEA,AdminHA);
           Superuser.update1(AdminUsername,AdminPass);
           model.setRowCount(0);
           DisplayAdmin();
           JOptionPane.showMessageDialog(null, "Admin Details Update Succesfully");
           
           
       }else{
            if(AdminDetailsTable.getRowCount()==0){
                JOptionPane.showMessageDialog(this,"Table is Empty");
            }
            else{
                JOptionPane.showMessageDialog(this,"Please select a Row");
            }
        }
       
       ConfirmBtn.setVisible(false);
       untxt.setText("");
       passtxt.setText("");
       PhoneNumtxt.setText("");
       emaddtxt.setText("");
       houseaddtxt.setText("");
       DeleteBtn.setVisible(true);
 
           
    }//GEN-LAST:event_ConfirmBtnMouseClicked
   
    private void DeleteBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeleteBtnMouseClicked
        DefaultTableModel model = (DefaultTableModel)AdminDetailsTable.getModel();
        String AdminUsername;
        if (AdminDetailsTable.getSelectedRowCount()==1){
            int selectedRow = AdminDetailsTable.getSelectedRow();
            AdminUsername = model.getValueAt(selectedRow,5).toString();
            Superuser.delete(AdminUsername);
            Superuser.delete1(AdminUsername);
            JOptionPane.showMessageDialog(null, "Admin Removed Succesfully");
            model.setRowCount(0);
            DisplayAdmin();
        }
        else{
            if(AdminDetailsTable.getRowCount()==0){
                JOptionPane.showMessageDialog(this,"Table is Empty");
            }
            else{
                JOptionPane.showMessageDialog(this,"Please select a Row");
            }
        }
        
    }//GEN-LAST:event_DeleteBtnMouseClicked

    private void CancelBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CancelBtnMouseClicked
       ConfirmBtn.setVisible(false);
       untxt.setText("");
       passtxt.setText("");
       PhoneNumtxt.setText("");
       emaddtxt.setText("");
       houseaddtxt.setText("");
       unlbl.setVisible(false);
       passlbl.setVisible(false);
       phonenumlbl.setVisible(false);
       emaddlbl.setVisible(false);
       houseaddlbl.setVisible(false);
       untxt.setVisible(false);
       passtxt.setVisible(false);
       PhoneNumtxt.setVisible(false);
       emaddtxt.setVisible(false);
       houseaddtxt.setVisible(false);
       UNline.setVisible(false);
       Passline.setVisible(false);
       PNline.setVisible(false);
       EAline.setVisible(false);
       HAline.setVisible(false);
       DeleteBtn.setVisible(true);
       CancelBtn.setVisible(false);
    }//GEN-LAST:event_CancelBtnMouseClicked

    private void DeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DeleteBtnActionPerformed
    
    
       
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable AdminDetailsTable;
    private javax.swing.JLabel AdminDetailslbl;
    private javax.swing.JButton CancelBtn;
    private javax.swing.JButton ConfirmBtn;
    private javax.swing.JButton DeleteBtn;
    private javax.swing.JLabel EAline;
    private javax.swing.JButton EditBtn;
    private javax.swing.JLabel HAline;
    private javax.swing.JLabel PNline;
    private javax.swing.JLabel Passline;
    private javax.swing.JTextField PhoneNumtxt;
    private javax.swing.JLabel UNline;
    private javax.swing.JLabel emaddlbl;
    private javax.swing.JTextField emaddtxt;
    private javax.swing.JLabel houseaddlbl;
    private javax.swing.JTextField houseaddtxt;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel passlbl;
    private javax.swing.JTextField passtxt;
    private javax.swing.JLabel phonenumlbl;
    private javax.swing.JLabel unlbl;
    private javax.swing.JLabel untxt;
    private javax.swing.JTextField untxt1;
    // End of variables declaration//GEN-END:variables
}
