/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package CarRental.Customer;

import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JOptionPane;


public class UpdatePasswordOption extends javax.swing.JFrame {
private static String AdminUsername;

    public UpdatePasswordOption(String username) {
        initComponents();
        AdminUsername = username;
        Toolkit toolkit= getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2); 
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        DeletePanel = new javax.swing.JPanel();
        DeleteCarDetailsllbl = new javax.swing.JLabel();
        UpdBtn = new javax.swing.JButton();
        Cancel = new javax.swing.JButton();
        Line3 = new javax.swing.JLabel();
        NewPasstxt = new javax.swing.JTextField();
        NewPassword = new javax.swing.JLabel();
        NewPassword1 = new javax.swing.JLabel();
        CPasstxt = new javax.swing.JTextField();
        Line4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(337, 349));
        setUndecorated(true);

        DeletePanel.setBackground(new java.awt.Color(255, 255, 255));
        DeletePanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        DeletePanel.setMaximumSize(new java.awt.Dimension(337, 349));
        DeletePanel.setMinimumSize(new java.awt.Dimension(337, 349));
        DeletePanel.setLayout(null);

        DeleteCarDetailsllbl.setFont(new java.awt.Font("Rockwell", 1, 18)); // NOI18N
        DeleteCarDetailsllbl.setForeground(new java.awt.Color(0, 0, 0));
        DeleteCarDetailsllbl.setText("Change Password");
        DeletePanel.add(DeleteCarDetailsllbl);
        DeleteCarDetailsllbl.setBounds(90, 30, 180, 30);

        UpdBtn.setBackground(new java.awt.Color(255, 255, 255));
        UpdBtn.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        UpdBtn.setForeground(new java.awt.Color(0, 0, 0));
        UpdBtn.setText("Update");
        UpdBtn.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                UpdBtnMouseMoved(evt);
            }
        });
        UpdBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UpdBtnMouseClicked(evt);
            }
        });
        DeletePanel.add(UpdBtn);
        UpdBtn.setBounds(120, 250, 100, 30);

        Cancel.setBackground(new java.awt.Color(0, 0, 0));
        Cancel.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        Cancel.setForeground(new java.awt.Color(255, 255, 255));
        Cancel.setText("Cancel");
        Cancel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CancelMouseClicked(evt);
            }
        });
        DeletePanel.add(Cancel);
        Cancel.setBounds(250, 310, 70, 24);

        Line3.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line3.setForeground(new java.awt.Color(0, 0, 0));
        Line3.setText("______________________________");
        Line3.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        DeletePanel.add(Line3);
        Line3.setBounds(80, 130, 200, 16);

        NewPasstxt.setBackground(new java.awt.Color(255, 255, 255));
        NewPasstxt.setFont(new java.awt.Font("Dialog", 2, 16)); // NOI18N
        NewPasstxt.setForeground(new java.awt.Color(0, 0, 0));
        NewPasstxt.setBorder(null);
        NewPasstxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NewPasstxtActionPerformed(evt);
            }
        });
        DeletePanel.add(NewPasstxt);
        NewPasstxt.setBounds(90, 110, 180, 30);

        NewPassword.setBackground(new java.awt.Color(255, 255, 255));
        NewPassword.setFont(new java.awt.Font("Constantia", 3, 16)); // NOI18N
        NewPassword.setForeground(new java.awt.Color(0, 0, 0));
        NewPassword.setText("New Password:");
        DeletePanel.add(NewPassword);
        NewPassword.setBounds(80, 90, 130, 30);

        NewPassword1.setBackground(new java.awt.Color(255, 255, 255));
        NewPassword1.setFont(new java.awt.Font("Constantia", 3, 16)); // NOI18N
        NewPassword1.setForeground(new java.awt.Color(0, 0, 0));
        NewPassword1.setText("Confirm Password:");
        DeletePanel.add(NewPassword1);
        NewPassword1.setBounds(80, 160, 170, 30);

        CPasstxt.setBackground(new java.awt.Color(255, 255, 255));
        CPasstxt.setFont(new java.awt.Font("Dialog", 2, 16)); // NOI18N
        CPasstxt.setForeground(new java.awt.Color(0, 0, 0));
        CPasstxt.setBorder(null);
        CPasstxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CPasstxtActionPerformed(evt);
            }
        });
        DeletePanel.add(CPasstxt);
        CPasstxt.setBounds(90, 180, 180, 30);

        Line4.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line4.setForeground(new java.awt.Color(0, 0, 0));
        Line4.setText("______________________________");
        Line4.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        DeletePanel.add(Line4);
        Line4.setBounds(80, 200, 200, 16);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(DeletePanel, javax.swing.GroupLayout.DEFAULT_SIZE, 337, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(DeletePanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 349, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void UpdBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdBtnMouseClicked
        String P = NewPasstxt.getText();
        String CP = CPasstxt.getText();
        
        if(P.equals(""))
        {
            JOptionPane.showMessageDialog(null,"Please enter your new password","Error",JOptionPane.ERROR_MESSAGE);
        }
        else if(P.length()<5){
            JOptionPane.showMessageDialog(null,"You Password must be atleast 5 characters","Error",JOptionPane.ERROR_MESSAGE);
        }
        else if(!P.equals(CP))
        {
            JOptionPane.showMessageDialog(null,"Both Password must be same","Error",JOptionPane.ERROR_MESSAGE);

        }
        else{
            
            Customer.CustomerUpdatePassword(AdminUsername, CP);
            Customer.UserUpdatePassword(AdminUsername, CP);
            dispose();
        }
    }//GEN-LAST:event_UpdBtnMouseClicked

    private void CancelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CancelMouseClicked
        dispose();
    }//GEN-LAST:event_CancelMouseClicked

    private void NewPasstxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NewPasstxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NewPasstxtActionPerformed

    private void CPasstxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CPasstxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CPasstxtActionPerformed

    private void UpdBtnMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdBtnMouseMoved
        
    }//GEN-LAST:event_UpdBtnMouseMoved

    
    public static void main(String args[]) {
       
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdatePasswordOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdatePasswordOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdatePasswordOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdatePasswordOption.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdatePasswordOption(AdminUsername).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField CPasstxt;
    private javax.swing.JButton Cancel;
    private javax.swing.JLabel DeleteCarDetailsllbl;
    private javax.swing.JPanel DeletePanel;
    private javax.swing.JLabel Line3;
    private javax.swing.JLabel Line4;
    private javax.swing.JTextField NewPasstxt;
    private javax.swing.JLabel NewPassword;
    private javax.swing.JLabel NewPassword1;
    private javax.swing.JButton UpdBtn;
    // End of variables declaration//GEN-END:variables
}
