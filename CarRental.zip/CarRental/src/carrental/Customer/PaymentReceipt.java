/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package CarRental.Customer;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class PaymentReceipt extends javax.swing.JFrame {
    private static String Booking_ID;
    private static String No_plate;
    private static String Ic_number;
    private static String Car_model;
    private static String Start_date;
    private static String End_date;
    private static String Rent_fee;
    private static String STATUS;
    

    public PaymentReceipt(String BookingID,String CarNoPlate,String IcNumber,String CarModel,String StartDate,String EndDate,String RentFee,String Status) {
        initComponents();
        Toolkit toolkit= getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
        Booking_ID = BookingID;
        No_plate = CarNoPlate;
        Ic_number = IcNumber;
        Car_model = CarModel;
        Start_date = StartDate;
        End_date = EndDate;
        Rent_fee = RentFee;
        STATUS = Status;
        DisplayReceipt();
        
    }
    
    private void DisplayReceipt(){
        String[] records;
        String line;
        File file = new File("Payment.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            while ((line = reader.readLine()) != null) {
                records = line.split(":");
                if (No_plate.equals(records[3])&&Ic_number.equals(records[1])){
                    String Paymentid = records[0];
                    String RentalFee = records[9];
                    String TotalFine = records[11];
                    String TotalRental = records[12];
                    
                    Date date = new Date();
                    SimpleDateFormat DateFor = new SimpleDateFormat("dd/MM/yyyy");
                    String StringDate= DateFor.format(date);
                    Date time = new Date();
                    String strDateFormat = "HH:mm:ss a";
                    SimpleDateFormat sdf = new SimpleDateFormat(strDateFormat);
                    receiptArea.setText(receiptArea.getText()+ " *********************************************************************  \n");
                    receiptArea.setText(receiptArea.getText()+ "                                           RECEIPT                 \n");
                    receiptArea.setText(receiptArea.getText()+ " *********************************************************************  \n");
                    receiptArea.setText(receiptArea.getText()+ "      Date: "+StringDate+ "");
                    receiptArea.setText(receiptArea.getText()+ "\n      Time: "+sdf.format(time)+ "");
                    receiptArea.setText(receiptArea.getText()+ "\n      Booking ID: "+Booking_ID+ "");
                    receiptArea.setText(receiptArea.getText()+ "\n      Payment ID: "+ Paymentid +"\n");
                    receiptArea.setText(receiptArea.getText()+ " *********************************************************************  \n");
                    receiptArea.setText(receiptArea.getText()+ "\n      Car Booking Details ");
                    receiptArea.setText(receiptArea.getText()+ "\n      Car No Plate:"+No_plate+"");
                    receiptArea.setText(receiptArea.getText()+ "\n      Car Model:"+Car_model+"");
                    receiptArea.setText(receiptArea.getText()+ "\n      Start Date:"+Start_date+"");
                    receiptArea.setText(receiptArea.getText()+ "\n      End Date:"+End_date+"");
                    receiptArea.setText(receiptArea.getText()+ "\n\n      Car Rental Payment");
                    receiptArea.setText(receiptArea.getText()+ "\n      Rental Fee:"+RentalFee+"");
                    receiptArea.setText(receiptArea.getText()+ "\n      Fine:"+TotalFine+"");
                    receiptArea.setText(receiptArea.getText()+ "\n  ====================");
                    receiptArea.setText(receiptArea.getText()+ "\n      Total Rental:"+TotalRental+"");
                    receiptArea.setText(receiptArea.getText()+ "\n  ====================");
                    receiptArea.setText(receiptArea.getText()+ "\n\n");
                    receiptArea.setText(receiptArea.getText()+ " *********************************************************************  \n");
                    receiptArea.setText(receiptArea.getText()+ "                       Thank You For Choosing Gas'N Go                    \n");
                    receiptArea.setText(receiptArea.getText()+ " ********************************************************************* ");
                    receiptArea.setEditable(false);
                    
                }
            }
            reader.close();
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        receiptArea = new javax.swing.JTextArea();
        Cancel = new javax.swing.JButton();
        print = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setMaximumSize(new java.awt.Dimension(600, 500));
        jPanel1.setMinimumSize(new java.awt.Dimension(600, 500));
        jPanel1.setPreferredSize(new java.awt.Dimension(600, 500));
        jPanel1.setLayout(null);

        receiptArea.setBackground(new java.awt.Color(255, 255, 255));
        receiptArea.setColumns(20);
        receiptArea.setRows(5);
        jScrollPane1.setViewportView(receiptArea);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(20, 20, 360, 450);

        Cancel.setBackground(new java.awt.Color(255, 51, 51));
        Cancel.setFont(new java.awt.Font("Franklin Gothic Book", 1, 12)); // NOI18N
        Cancel.setForeground(new java.awt.Color(0, 0, 0));
        Cancel.setText("CANCEL");
        Cancel.setBorder(null);
        Cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelActionPerformed(evt);
            }
        });
        jPanel1.add(Cancel);
        Cancel.setBounds(20, 490, 180, 30);

        print.setBackground(new java.awt.Color(102, 204, 255));
        print.setFont(new java.awt.Font("Franklin Gothic Book", 1, 12)); // NOI18N
        print.setForeground(new java.awt.Color(0, 0, 0));
        print.setText("PRINT");
        print.setBorder(null);
        print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printActionPerformed(evt);
            }
        });
        jPanel1.add(print);
        print.setBounds(200, 490, 180, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 401, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 536, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelActionPerformed
        dispose();
    }//GEN-LAST:event_CancelActionPerformed

    private void printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_printActionPerformed

    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PaymentReceipt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PaymentReceipt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PaymentReceipt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PaymentReceipt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PaymentReceipt(Booking_ID,No_plate,Ic_number,Car_model,Start_date,End_date,Rent_fee,STATUS).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cancel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton print;
    private javax.swing.JTextArea receiptArea;
    // End of variables declaration//GEN-END:variables
}
