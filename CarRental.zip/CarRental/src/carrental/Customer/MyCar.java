/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package CarRental.Customer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Lashvin
 */
public class MyCar extends javax.swing.JInternalFrame {
    private static String CustomerUsername; 
    public MyCar(String username) {
        CustomerUsername = username;
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI)this.getUI();
        ui.setNorthPane(null);
        GetCusICNumber();
        DisplayCarBookings();
    }
    
    private void GetCusICNumber(){
        String[] records;
        String line;
        File file = new File("Customer.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            while ((line = reader.readLine()) != null) {
                records = line.split(":");
                String CusIcNumber  = (records[1]);
                String CusUN = (records[4]);
                if (CustomerUsername.equals(CusUN)){
                    String GetCusIcNumber = CusIcNumber;
                    FakeLbl.setText(GetCusIcNumber);
                }
            }
            reader.close();
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
    }
    
    private void DisplayCarBookings(){
                
        File f = new File("CarBookings.txt");
        int check=0;
        int check1 = 0;
        String icNUMBER = FakeLbl.getText();
        if(icNUMBER.equals("")){
            check=1;
            JOptionPane.showInternalMessageDialog(null, "Car Booking is required");
        }
        else{
        try{BufferedReader br = new BufferedReader(new FileReader(f));
        DefaultTableModel model = (DefaultTableModel)CarBookings.getModel();
        model.setRowCount(0);
        Object[] Lines = br.lines().toArray();

            for(int i=0; i< Lines.length ; i++){
            String Line = Lines[i].toString().trim();
            String[] Row = Line.split(":");
            if(FakeLbl.getText().equals(Row[2])){
                check1++;
                model.addRow(Row);
            }
            }
            if (check1 == 0){
                JOptionPane.showMessageDialog(this, "No Car Bookings Founded, Please make a booking.","Warning", JOptionPane.WARNING_MESSAGE);
            }
            else{
                //JOptionPane.showInternalMessageDialog(null, "Car Bookings Founded");
            }
        }catch(Exception ex){
        }
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        CarBookings = new javax.swing.JTable();
        FakeLbl = new javax.swing.JLabel();
        ReturnCar = new javax.swing.JButton();
        GenerateReceipt = new javax.swing.JButton();
        UpdateTableBtn = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(780, 530));
        jPanel1.setMinimumSize(new java.awt.Dimension(780, 530));
        jPanel1.setPreferredSize(new java.awt.Dimension(780, 530));
        jPanel1.setLayout(null);

        CarBookings.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Booking ID", "No Plate", "IC Number", "Car Model", "Start Date", "End Date", "Rent Fee", "Status"
            }
        ));
        CarBookings.setSelectionBackground(new java.awt.Color(204, 255, 255));
        CarBookings.setSelectionForeground(new java.awt.Color(0, 0, 0));
        jScrollPane1.setViewportView(CarBookings);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(10, 60, 750, 350);

        FakeLbl.setBackground(new java.awt.Color(255, 255, 255));
        FakeLbl.setForeground(new java.awt.Color(255, 255, 255));
        FakeLbl.setText("jLabel1");
        jPanel1.add(FakeLbl);
        FakeLbl.setBounds(30, 410, 10, 15);

        ReturnCar.setBackground(new java.awt.Color(0, 0, 0));
        ReturnCar.setFont(new java.awt.Font("Franklin Gothic Book", 1, 12)); // NOI18N
        ReturnCar.setForeground(new java.awt.Color(255, 255, 255));
        ReturnCar.setText("RETURN CAR");
        ReturnCar.setBorder(null);
        ReturnCar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnCarActionPerformed(evt);
            }
        });
        jPanel1.add(ReturnCar);
        ReturnCar.setBounds(150, 440, 170, 40);

        GenerateReceipt.setBackground(new java.awt.Color(0, 0, 0));
        GenerateReceipt.setFont(new java.awt.Font("Franklin Gothic Book", 1, 12)); // NOI18N
        GenerateReceipt.setForeground(new java.awt.Color(255, 255, 255));
        GenerateReceipt.setText("GENERATE RECEIPT");
        GenerateReceipt.setBorder(null);
        GenerateReceipt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GenerateReceiptActionPerformed(evt);
            }
        });
        jPanel1.add(GenerateReceipt);
        GenerateReceipt.setBounds(440, 440, 220, 40);

        UpdateTableBtn.setBackground(new java.awt.Color(0, 0, 0));
        UpdateTableBtn.setForeground(new java.awt.Color(255, 255, 255));
        UpdateTableBtn.setText("Update Table");
        UpdateTableBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UpdateTableBtnMouseClicked(evt);
            }
        });
        UpdateTableBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateTableBtnActionPerformed(evt);
            }
        });
        jPanel1.add(UpdateTableBtn);
        UpdateTableBtn.setBounds(623, 15, 110, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 780, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 585, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ReturnCarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnCarActionPerformed
        int i = CarBookings.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)CarBookings.getModel();
        if(i >=0){
            int selectedRow = CarBookings.getSelectedRow();
            String CarNoPlate = model.getValueAt(selectedRow,1).toString();
            String Status = model.getValueAt(selectedRow,7).toString();
            if(Status.equals("Completed")){
                JOptionPane.showMessageDialog(this,"This car has been returned");  
            }
            if(Status.equals("Approved")){
                
                Customer rc = new Customer(CarNoPlate, FakeLbl.getText());
                Vector message = rc.returnCar();
                double amount = Double.parseDouble(message.get(0).toString());
                String days = message.get(1).toString();
                double fine = Double.parseDouble(message.get(2).toString());
                double totalAmount = Double.parseDouble(message.get(3).toString());
                String State = message.get(4).toString();

                if (State.equals("Failure")){

                }
                else if (State.equals("Success")){
                    ReturnMyCar.setAmount(amount);
                    ReturnMyCar.setDays(days);
                    ReturnMyCar.setFine(fine);
                    ReturnMyCar.setTotalfee(totalAmount);
                    ReturnCar RC = new ReturnCar(CustomerUsername,CarNoPlate);
                    RC.setVisible(true);
                }
                
            }
            else{
                JOptionPane.showMessageDialog(this,"This car haven't been approved");  
            }
        }else{
            if(CarBookings.getRowCount()==0){
                JOptionPane.showMessageDialog(this,"Table is Empty");
            }
            else{
                JOptionPane.showMessageDialog(this,"Please select a Row");
            }
        }
        
        
        
    }//GEN-LAST:event_ReturnCarActionPerformed

    private void GenerateReceiptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GenerateReceiptActionPerformed
        String CarNoPlate;
        String IcNumber;
        String CarModel;
        String StartDate;
        String EndDate;
        String RentFee;
        String Status;
        String BookingID;
        DefaultTableModel model = (DefaultTableModel)CarBookings.getModel();    
        if (CarBookings.getSelectedRowCount()==1){
            int selectedRow = CarBookings.getSelectedRow();
            BookingID = model.getValueAt(selectedRow,0).toString();
            CarNoPlate = model.getValueAt(selectedRow,1).toString();
            IcNumber = model.getValueAt(selectedRow,2).toString();
            CarModel = model.getValueAt(selectedRow,3).toString();
            StartDate = model.getValueAt(selectedRow,4).toString();
            EndDate = model.getValueAt(selectedRow,5).toString();
            RentFee = model.getValueAt(selectedRow,6).toString();
            Status = model.getValueAt(selectedRow,7).toString();
            
            if(Status.equals("Completed")){
                PaymentReceipt R = new PaymentReceipt(BookingID,CarNoPlate,IcNumber,CarModel,StartDate,EndDate,RentFee,Status);
                R.setVisible(true);
                model.setRowCount(0);
                DisplayCarBookings();

            }
            else{
                 JOptionPane.showMessageDialog(this,"This car havent complete payment");  
            }
        }
        else{
            if(CarBookings.getRowCount()==0){
                JOptionPane.showMessageDialog(this,"Table is Empty");
            }
            else{
                JOptionPane.showMessageDialog(this,"Please select a Row");
            }
        }    
    }//GEN-LAST:event_GenerateReceiptActionPerformed

    private void UpdateTableBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdateTableBtnMouseClicked
        DefaultTableModel model = (DefaultTableModel)CarBookings.getModel();
        model.setRowCount(0);
        DisplayCarBookings();
    }//GEN-LAST:event_UpdateTableBtnMouseClicked

    private void UpdateTableBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateTableBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UpdateTableBtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable CarBookings;
    private javax.swing.JLabel FakeLbl;
    private javax.swing.JButton GenerateReceipt;
    private javax.swing.JButton ReturnCar;
    private javax.swing.JButton UpdateTableBtn;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
