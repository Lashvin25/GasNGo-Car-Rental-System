/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package CarRental.Customer;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author Lashvin
 */
public class Payment extends javax.swing.JFrame {
    private static String CustomerUsername;
    private static String CarNoPlate;
    private static String Car_Model;
    private static String SD;
    private static String ED;
    private static String TotalFee;
    

    public Payment(String username,String NoPlate,String CarModel, String StartDate, String EndDate, String RentFee) {
        initComponents();
        CustomerUsername = username;
        CarNoPlate = NoPlate;
        Car_Model = CarModel;
        SD = StartDate;
        ED = EndDate;
        TotalFee = RentFee;
        Toolkit toolkit= getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
        GetCusICNumber();
    }
    private void GetCusICNumber(){
        String[] records;
        String line;
        File file = new File("Customer.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            while ((line = reader.readLine()) != null) {
                records = line.split(":");
                String CusIcNumber  = (records[1]);
                String CusUN = (records[4]);
                if (CustomerUsername.equals(CusUN)){
                    String GetCusIcNumber = CusIcNumber;
                    FakeLbl.setText(GetCusIcNumber);
                }
            }
            reader.close();
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        LoginPagePanel2 = new javax.swing.JPanel();
        SignUpQLabel1 = new javax.swing.JLabel();
        Paymentlbl = new javax.swing.JLabel();
        SignUpQLabel2 = new javax.swing.JLabel();
        Namelbl = new javax.swing.JLabel();
        HolderName = new javax.swing.JTextField();
        Line1 = new javax.swing.JLabel();
        Hilbl = new javax.swing.JLabel();
        Namelbl1 = new javax.swing.JLabel();
        SignUpQLabel4 = new javax.swing.JLabel();
        CVV = new javax.swing.JTextField();
        Line2 = new javax.swing.JLabel();
        Namelbl2 = new javax.swing.JLabel();
        SignUpQLabel5 = new javax.swing.JLabel();
        Line3 = new javax.swing.JLabel();
        CardNumber = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        SignUpQLabel6 = new javax.swing.JLabel();
        Namelbl3 = new javax.swing.JLabel();
        Month = new javax.swing.JTextField();
        Line4 = new javax.swing.JLabel();
        Line5 = new javax.swing.JLabel();
        Year = new javax.swing.JTextField();
        Namelbl4 = new javax.swing.JLabel();
        BookNow = new javax.swing.JButton();
        close = new javax.swing.JLabel();
        FakeLbl = new javax.swing.JLabel();
        Hilbl1 = new javax.swing.JLabel();
        LoginPageLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 550));
        setUndecorated(true);

        jPanel1.setMaximumSize(new java.awt.Dimension(1000, 550));
        jPanel1.setMinimumSize(new java.awt.Dimension(1000, 550));
        jPanel1.setLayout(null);

        LoginPagePanel2.setBackground(new java.awt.Color(255, 255, 255));
        LoginPagePanel2.setLayout(null);

        SignUpQLabel1.setFont(new java.awt.Font("Gadugi", 1, 10)); // NOI18N
        SignUpQLabel1.setForeground(new java.awt.Color(153, 153, 153));
        SignUpQLabel1.setText("VISA/MASTERCARD");
        LoginPagePanel2.add(SignUpQLabel1);
        SignUpQLabel1.setBounds(50, 40, 140, 15);

        Paymentlbl.setBackground(new java.awt.Color(0, 0, 0));
        Paymentlbl.setFont(new java.awt.Font("Ebrima", 1, 24)); // NOI18N
        Paymentlbl.setForeground(new java.awt.Color(0, 0, 0));
        Paymentlbl.setText("Book Car");
        LoginPagePanel2.add(Paymentlbl);
        Paymentlbl.setBounds(50, 50, 330, 40);

        SignUpQLabel2.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        SignUpQLabel2.setForeground(new java.awt.Color(153, 153, 153));
        SignUpQLabel2.setText("Enter the card holder name ");
        LoginPagePanel2.add(SignUpQLabel2);
        SignUpQLabel2.setBounds(50, 130, 280, 40);

        Namelbl.setBackground(new java.awt.Color(255, 255, 255));
        Namelbl.setFont(new java.awt.Font("Constantia", 3, 16)); // NOI18N
        Namelbl.setForeground(new java.awt.Color(0, 0, 0));
        Namelbl.setText("Card Holder's Name");
        LoginPagePanel2.add(Namelbl);
        Namelbl.setBounds(50, 120, 210, 30);

        HolderName.setBackground(new java.awt.Color(255, 255, 255));
        HolderName.setFont(new java.awt.Font("Dialog", 2, 16)); // NOI18N
        HolderName.setForeground(new java.awt.Color(153, 153, 153));
        HolderName.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        HolderName.setText("Gas'N GO Car Rental");
        HolderName.setToolTipText("");
        HolderName.setBorder(null);
        HolderName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                HolderNameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                HolderNameFocusLost(evt);
            }
        });
        HolderName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HolderNameActionPerformed(evt);
            }
        });
        HolderName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                HolderNameKeyTyped(evt);
            }
        });
        LoginPagePanel2.add(HolderName);
        HolderName.setBounds(50, 170, 490, 30);

        Line1.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line1.setForeground(new java.awt.Color(0, 0, 0));
        Line1.setText("___________________________________________________________________________________");
        Line1.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        LoginPagePanel2.add(Line1);
        Line1.setBounds(50, 190, 490, 16);

        Hilbl.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        Hilbl.setForeground(new java.awt.Color(153, 153, 153));
        Hilbl.setText("Payment wont be made until car has been returned");
        LoginPagePanel2.add(Hilbl);
        Hilbl.setBounds(600, 400, 280, 15);

        Namelbl1.setBackground(new java.awt.Color(255, 255, 255));
        Namelbl1.setFont(new java.awt.Font("Constantia", 0, 24)); // NOI18N
        Namelbl1.setForeground(new java.awt.Color(153, 153, 153));
        Namelbl1.setText("/");
        LoginPagePanel2.add(Namelbl1);
        Namelbl1.setBounds(420, 360, 10, 40);

        SignUpQLabel4.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        SignUpQLabel4.setForeground(new java.awt.Color(153, 153, 153));
        SignUpQLabel4.setText("Enter the 16 Digit Card Number in the back");
        LoginPagePanel2.add(SignUpQLabel4);
        SignUpQLabel4.setBounds(50, 250, 280, 30);

        CVV.setBackground(new java.awt.Color(255, 255, 255));
        CVV.setFont(new java.awt.Font("Dialog", 2, 16)); // NOI18N
        CVV.setForeground(new java.awt.Color(153, 153, 153));
        CVV.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        CVV.setText(" 0321");
        CVV.setBorder(null);
        CVV.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                CVVFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                CVVFocusLost(evt);
            }
        });
        CVV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CVVActionPerformed(evt);
            }
        });
        CVV.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                CVVKeyTyped(evt);
            }
        });
        LoginPagePanel2.add(CVV);
        CVV.setBounds(330, 300, 190, 30);

        Line2.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line2.setForeground(new java.awt.Color(0, 0, 0));
        Line2.setText("______________________________________");
        Line2.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        LoginPagePanel2.add(Line2);
        Line2.setBounds(300, 260, 250, 16);

        Namelbl2.setBackground(new java.awt.Color(255, 255, 255));
        Namelbl2.setFont(new java.awt.Font("Constantia", 3, 16)); // NOI18N
        Namelbl2.setForeground(new java.awt.Color(0, 0, 0));
        Namelbl2.setText("CVV Number");
        LoginPagePanel2.add(Namelbl2);
        Namelbl2.setBounds(50, 290, 130, 30);

        SignUpQLabel5.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        SignUpQLabel5.setForeground(new java.awt.Color(153, 153, 153));
        SignUpQLabel5.setText("Enter the 3 or 4 Digit number");
        LoginPagePanel2.add(SignUpQLabel5);
        SignUpQLabel5.setBounds(50, 310, 280, 30);

        Line3.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line3.setForeground(new java.awt.Color(0, 0, 0));
        Line3.setText("______________________________________");
        Line3.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        LoginPagePanel2.add(Line3);
        Line3.setBounds(300, 320, 250, 16);

        CardNumber.setBackground(new java.awt.Color(255, 255, 255));
        CardNumber.setFont(new java.awt.Font("Dialog", 2, 16)); // NOI18N
        CardNumber.setForeground(new java.awt.Color(153, 153, 153));
        CardNumber.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        CardNumber.setText("****  ****  ****  3456");
        CardNumber.setToolTipText("");
        CardNumber.setBorder(null);
        CardNumber.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                CardNumberFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                CardNumberFocusLost(evt);
            }
        });
        CardNumber.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                CardNumberKeyTyped(evt);
            }
        });
        LoginPagePanel2.add(CardNumber);
        CardNumber.setBounds(300, 240, 240, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/carrental/Source/IMG_2385.gif"))); // NOI18N
        LoginPagePanel2.add(jLabel1);
        jLabel1.setBounds(600, 80, 260, 230);

        SignUpQLabel6.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        SignUpQLabel6.setForeground(new java.awt.Color(153, 153, 153));
        SignUpQLabel6.setText("Enter the month & year in the card");
        LoginPagePanel2.add(SignUpQLabel6);
        SignUpQLabel6.setBounds(50, 370, 230, 30);

        Namelbl3.setBackground(new java.awt.Color(255, 255, 255));
        Namelbl3.setFont(new java.awt.Font("Constantia", 3, 16)); // NOI18N
        Namelbl3.setForeground(new java.awt.Color(0, 0, 0));
        Namelbl3.setText("Expiry Date");
        LoginPagePanel2.add(Namelbl3);
        Namelbl3.setBounds(50, 350, 130, 30);

        Month.setBackground(new java.awt.Color(255, 255, 255));
        Month.setFont(new java.awt.Font("Dialog", 2, 16)); // NOI18N
        Month.setForeground(new java.awt.Color(153, 153, 153));
        Month.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Month.setText("month");
        Month.setBorder(null);
        Month.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                MonthFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                MonthFocusLost(evt);
            }
        });
        Month.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                MonthKeyTyped(evt);
            }
        });
        LoginPagePanel2.add(Month);
        Month.setBounds(320, 360, 80, 30);

        Line4.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line4.setForeground(new java.awt.Color(0, 0, 0));
        Line4.setText("__________________");
        Line4.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        LoginPagePanel2.add(Line4);
        Line4.setBounds(300, 380, 130, 16);

        Line5.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line5.setForeground(new java.awt.Color(0, 0, 0));
        Line5.setText("__________________");
        Line5.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        LoginPagePanel2.add(Line5);
        Line5.setBounds(430, 380, 130, 16);

        Year.setBackground(new java.awt.Color(255, 255, 255));
        Year.setFont(new java.awt.Font("Dialog", 2, 16)); // NOI18N
        Year.setForeground(new java.awt.Color(153, 153, 153));
        Year.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Year.setText("year");
        Year.setBorder(null);
        Year.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                YearFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                YearFocusLost(evt);
            }
        });
        Year.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                YearKeyTyped(evt);
            }
        });
        LoginPagePanel2.add(Year);
        Year.setBounds(450, 360, 80, 30);

        Namelbl4.setBackground(new java.awt.Color(255, 255, 255));
        Namelbl4.setFont(new java.awt.Font("Constantia", 3, 16)); // NOI18N
        Namelbl4.setForeground(new java.awt.Color(0, 0, 0));
        Namelbl4.setText("Card Number");
        LoginPagePanel2.add(Namelbl4);
        Namelbl4.setBounds(50, 230, 130, 30);

        BookNow.setBackground(new java.awt.Color(0, 51, 204));
        BookNow.setFont(new java.awt.Font("Franklin Gothic Book", 1, 12)); // NOI18N
        BookNow.setForeground(new java.awt.Color(255, 255, 255));
        BookNow.setText("BOOK NOW");
        BookNow.setBorder(null);
        BookNow.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BookNowMouseClicked(evt);
            }
        });
        BookNow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BookNowActionPerformed(evt);
            }
        });
        LoginPagePanel2.add(BookNow);
        BookNow.setBounds(640, 340, 200, 50);

        close.setFont(new java.awt.Font("Segoe UI Emoji", 1, 24)); // NOI18N
        close.setForeground(new java.awt.Color(102, 102, 102));
        close.setText("X");
        close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeMouseClicked(evt);
            }
        });
        LoginPagePanel2.add(close);
        close.setBounds(860, 10, 40, 30);

        FakeLbl.setBackground(new java.awt.Color(255, 255, 255));
        FakeLbl.setForeground(new java.awt.Color(255, 255, 255));
        LoginPagePanel2.add(FakeLbl);
        FakeLbl.setBounds(450, 50, 0, 0);

        Hilbl1.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        Hilbl1.setForeground(new java.awt.Color(153, 153, 153));
        Hilbl1.setText("Please enter card holder details for booking confirmation.");
        LoginPagePanel2.add(Hilbl1);
        Hilbl1.setBounds(50, 90, 300, 15);

        jPanel1.add(LoginPagePanel2);
        LoginPagePanel2.setBounds(50, 50, 900, 450);

        LoginPageLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/carrental/Source/Gradient.jpg"))); // NOI18N
        jPanel1.add(LoginPageLabel1);
        LoginPageLabel1.setBounds(0, 0, 1000, 550);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 550, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void HolderNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_HolderNameFocusGained
        if(HolderName.getText().equals("Gas'N GO Car Rental")){
            HolderName.setText("");
            HolderName.setForeground(Color.black);
        }
    }//GEN-LAST:event_HolderNameFocusGained

    private void HolderNameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_HolderNameFocusLost
        if(HolderName.getText().equals("")){
            HolderName.setText("Gas'N GO Car Rental");
            HolderName.setForeground(Color.gray);
        }
    }//GEN-LAST:event_HolderNameFocusLost

    private void CVVFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_CVVFocusLost
        if(CVV.getText().equals("")){
            CVV.setText(" 0321");
            CVV.setForeground(Color.gray);
        }
    }//GEN-LAST:event_CVVFocusLost

    private void CVVFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_CVVFocusGained
        if(CVV.getText().equals(" 0321")){
            CVV.setText("");
            CVV.setForeground(Color.black);
        }
    }//GEN-LAST:event_CVVFocusGained

    private void CardNumberFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_CardNumberFocusGained
        if(CardNumber.getText().equals("****  ****  ****  3456")){
            CardNumber.setText("");
            CardNumber.setForeground(Color.black);
        }
    }//GEN-LAST:event_CardNumberFocusGained

    private void CardNumberFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_CardNumberFocusLost
        if(CardNumber.getText().equals("")){
            CardNumber.setText("****  ****  ****  3456");
            CardNumber.setForeground(Color.gray);
        }
    }//GEN-LAST:event_CardNumberFocusLost

    private void MonthFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_MonthFocusGained
        if(Month.getText().equals("month")){
            Month.setText("");
            Month.setForeground(Color.black);
        }
    }//GEN-LAST:event_MonthFocusGained

    private void MonthFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_MonthFocusLost
        if(Month.getText().equals("")){
            Month.setText("month");
            Month.setForeground(Color.gray);
        }
    }//GEN-LAST:event_MonthFocusLost

    private void YearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_YearFocusGained
        if(Year.getText().equals("year")){
            Year.setText("");
            Year.setForeground(Color.black);
        }
    }//GEN-LAST:event_YearFocusGained

    private void YearFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_YearFocusLost
        if(Year.getText().equals("")){
            Year.setText("year");
            Year.setForeground(Color.gray);
        }
    }//GEN-LAST:event_YearFocusLost

    private void BookNowMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BookNowMouseClicked
        
    }//GEN-LAST:event_BookNowMouseClicked

    private void BookNowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BookNowActionPerformed
        String CUSicNumber = FakeLbl.getText();
        String CardName = HolderName.getText();
        String Card_Number = CardNumber.getText();
        String CVVNumber = CVV.getText();
        String MonthNumber = Month.getText();
        String YearNumber = Year.getText();
        
        if (CardName.equals("")|| Card_Number.equals("")|| CVVNumber.equals("") || MonthNumber.equals("")|| YearNumber.equals("")){
            JOptionPane.showMessageDialog(null,"Please fill out all required fields","Error",JOptionPane.ERROR_MESSAGE);
        }
        else if (CardName.equals("Gas'N GO Car Rental")|| Card_Number.equals("****  ****  ****  3456")|| CVVNumber.equals(" 0321") || MonthNumber.equals("month")|| YearNumber.equals("year")){
            JOptionPane.showMessageDialog(null,"Please fill out all required fields","Error",JOptionPane.ERROR_MESSAGE);
        }
        else if (Card_Number.length()<16){
            JOptionPane.showMessageDialog(null,"Your Card Number must be 16 numbers","Error",JOptionPane.ERROR_MESSAGE);
        }
        else if (Card_Number.length()==1 || Card_Number.length()==2 || Card_Number.length()==3 || Card_Number.length()==4 || Card_Number.length()==5 ||
                Card_Number.length()==6 || Card_Number.length()==7 || Card_Number.length()==8 || Card_Number.length()==9 || Card_Number.length()==10 ||
                Card_Number.length()==11 || Card_Number.length()==12 || Card_Number.length()==13 || Card_Number.length()==14 || Card_Number.length()==15){
            JOptionPane.showMessageDialog(null,"Your Card Number must be 16 numbers","Error",JOptionPane.ERROR_MESSAGE);
        }
        else if (CVVNumber.length()<4 && CVVNumber.length()<3) {
            JOptionPane.showMessageDialog(null,"Your CVV Number must be 3 or 4 numbers","Error",JOptionPane.ERROR_MESSAGE);
        }
        else if (CVVNumber.length()==2 || CVVNumber.length()==1){
            JOptionPane.showMessageDialog(null,"Your CVV Number must be 3 or 4 numbers","Error",JOptionPane.ERROR_MESSAGE);
        }
        else if (MonthNumber.length()<2){
            JOptionPane.showMessageDialog(null,"Please input correct month between 01-12","Error",JOptionPane.ERROR_MESSAGE);
        }
        else if (YearNumber.length()<2){
            JOptionPane.showMessageDialog(null,"Please input correct year. Example, 25","Error",JOptionPane.ERROR_MESSAGE);
        }
        else{
            
            Customer CUS = new Customer(CarNoPlate,CUSicNumber,Car_Model,SD,ED,TotalFee);
            CUS.CustomerBookCar();
            Customer PAY = new Customer(CUSicNumber, CustomerUsername, CarNoPlate, CardName, Card_Number,CVVNumber, MonthNumber, YearNumber, TotalFee);
            PAY.CustomerPayment();  
            JOptionPane.showMessageDialog(this,"You have successfully booked a car,Please check MyCar for further details");
            dispose();
            
        }
    }//GEN-LAST:event_BookNowActionPerformed

    private void closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeMouseClicked
        
        Object[] message = {
                "Are you sure you want to cancel this booking?",
        };
        
        int ab  = JOptionPane.showConfirmDialog(null, message, "Cancel Booking", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null);
        if(ab == JOptionPane.YES_OPTION){ 
            dispose();
        }
    }//GEN-LAST:event_closeMouseClicked

    private void HolderNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HolderNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_HolderNameActionPerformed

    private void CVVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CVVActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CVVActionPerformed

    private void CardNumberKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CardNumberKeyTyped
        char c = evt.getKeyChar();
        
        if (!Character.isDigit(c)){
            evt.consume();
        }
    }//GEN-LAST:event_CardNumberKeyTyped

    private void CVVKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CVVKeyTyped
        char c = evt.getKeyChar();
        
        if (!Character.isDigit(c)){
            evt.consume();
        }        
    }//GEN-LAST:event_CVVKeyTyped

    private void MonthKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_MonthKeyTyped
        char c = evt.getKeyChar();
        
        if (!Character.isDigit(c)){
            evt.consume();
        }
    }//GEN-LAST:event_MonthKeyTyped

    private void YearKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_YearKeyTyped
        char c = evt.getKeyChar();
        
        if (!Character.isDigit(c)){
            evt.consume();
        }
    }//GEN-LAST:event_YearKeyTyped

    private void HolderNameKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_HolderNameKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isLetter(c) || Character.isWhitespace(c)|| Character.isISOControl(c)){
            HolderName.setEditable(true);
        }
        else{
            HolderName.setEditable(false);
        }
    }//GEN-LAST:event_HolderNameKeyTyped

    public static void main(String args[]) {
        
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Payment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Payment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Payment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Payment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Payment(CustomerUsername,CarNoPlate,Car_Model,SD,ED,TotalFee).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BookNow;
    private javax.swing.JTextField CVV;
    private javax.swing.JTextField CardNumber;
    private javax.swing.JLabel FakeLbl;
    private javax.swing.JLabel Hilbl;
    private javax.swing.JLabel Hilbl1;
    private javax.swing.JTextField HolderName;
    private javax.swing.JLabel Line1;
    private javax.swing.JLabel Line2;
    private javax.swing.JLabel Line3;
    private javax.swing.JLabel Line4;
    private javax.swing.JLabel Line5;
    private javax.swing.JLabel LoginPageLabel1;
    private javax.swing.JPanel LoginPagePanel2;
    private javax.swing.JTextField Month;
    private javax.swing.JLabel Namelbl;
    private javax.swing.JLabel Namelbl1;
    private javax.swing.JLabel Namelbl2;
    private javax.swing.JLabel Namelbl3;
    private javax.swing.JLabel Namelbl4;
    private javax.swing.JLabel Paymentlbl;
    private javax.swing.JLabel SignUpQLabel1;
    private javax.swing.JLabel SignUpQLabel2;
    private javax.swing.JLabel SignUpQLabel4;
    private javax.swing.JLabel SignUpQLabel5;
    private javax.swing.JLabel SignUpQLabel6;
    private javax.swing.JTextField Year;
    private javax.swing.JLabel close;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
