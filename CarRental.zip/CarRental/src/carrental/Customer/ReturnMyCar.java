/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CarRental.Customer;

/**
 *
 * @author Lashvin
 */
public class ReturnMyCar {
    static double amount;
    static String days;
    static double fine;
    static double totalfee;

    public static double getAmount() {
        return amount;
    }

    public static void setAmount(double amount) {
        ReturnMyCar.amount = amount;
    }

    public static String getDays() {
        return days;
    }

    public static void setDays(String days) {
        ReturnMyCar.days = days;
    }

    public static double getFine() {
        return fine;
    }

    public static void setFine(double fine) {
        ReturnMyCar.fine = fine;
    }

    public static double getTotalfee() {
        return totalfee;
    }

    public static void setTotalfee(double totalfee) {
        ReturnMyCar.totalfee = totalfee;
    }
    
}
