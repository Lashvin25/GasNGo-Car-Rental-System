/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CarRental.Customer;

import CarRental.User.SignIn;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;

/**
 *
 * @author Lashvin
 */
public class Customer {
    String CusName;
    String CusICNum;
    String CusPNum;
    String CusEAdd;
    String CusUN;
    String CusPass;
    String CusSW;
    String CarNoPlate;
    String CusIC_number;
    String Car_Model;
    String Start_Date;
    String End_Date;
    String Rent_Fee;
    String Customer_IC_Number;
    String Customer_Username;
    String Customer_CardName;
    String Customer_CardNumber;
    String Customer_CVV;
    String Customer_Month;
    String Customer_Year;
    String Customer_TotalRentalFee;
    String Car_NO_PLATE;
    String carNo;
    String custICNUMBER;
    
    String CarFee;
    String CarFine;
    String CarTotalFee;
    String CICN;
    String CCN;
    String CN;
    String CVVN;
    String CDN;
    String CMN;
    String CYN;
    String feedback;
    
    
    public Customer(String carNo, String icnumber){
        this.carNo = carNo;
        this.custICNUMBER = icnumber;
    }
    
    public Customer(String CustomerICnumber, String Customer_CARNO, String Fee,String Fine,String TotalFee,String Card_Name, String Card_Number,String CVVNumber,String MonthNumber,String YearNumber, String FeedBack
    ){  
        this.CarFee = Fee;
        this.CarFine = Fine;
        this.CarTotalFee = TotalFee;
        this.CICN = CustomerICnumber;
        this.CCN=Customer_CARNO;
        this.CN = Card_Name;
        this.CVVN = CVVNumber;
        this.CDN = Card_Number;
        this.CMN = MonthNumber;
        this.CYN = YearNumber;  
        this.feedback = FeedBack;
    }
    
    public Customer(String CusName,String CusICNum,String CusPNum,String CusEAdd,String CusUN,String CusPass,String CusSW){
       this.CusName = CusName;
       this.CusICNum = CusICNum;
       this.CusPNum = CusPNum;
       this.CusEAdd = CusEAdd;
       this.CusUN = CusUN;
       this.CusPass = CusPass;
       this.CusSW = CusSW;
    }
    
    public Customer(String NoPlate, String ICnumber,String CarModel, String StartDate, String EndDate, String RentFee){
       this.CarNoPlate = NoPlate;
       this.CusIC_number = ICnumber;
       this.Car_Model = CarModel;
       this.Start_Date = StartDate;
       this.End_Date = EndDate;
       this.Rent_Fee = RentFee;
    }
    
    public Customer(String CustomerIC,String CustomerUsername, String CARNOPLATE,String CardName, String CardNumber,String CVV, String Month, String Year, String TotalRentalFee){
        this.Customer_IC_Number = CustomerIC;
        this.Customer_Username = CustomerUsername;
        this.Customer_CardName = CardName;
        this.Customer_CardNumber = CardNumber;
        this.Customer_CVV = CVV;
        this.Customer_Month = Month;
        this.Customer_Year = Year;
        this.Customer_TotalRentalFee= TotalRentalFee;
        this.Car_NO_PLATE = CARNOPLATE;
        
        
    }
       
    public void AddCustomer(){
        try{
                BufferedReader bufferedReader =  new BufferedReader(new FileReader("User.txt"));
                String line;
                String chck_username;
                BufferedReader bufferedReader1 =  new BufferedReader(new FileReader("Customer.txt"));
                String records;
                String chck_icnumber;
                
                boolean found = false;
                while((line = bufferedReader.readLine()) != null){
                    String[] column = line.split(":");
                    chck_username = column[0];
                    if(chck_username.equals(CusUN)){
                        found = true;
                        JOptionPane.showMessageDialog(null,"Username already exist","Username Existed",JOptionPane.ERROR_MESSAGE);
                    }
                    else{
                        while((records = bufferedReader1.readLine()) != null){
                            String[] row = records.split(":");
                            chck_icnumber = row[1];
                            if(chck_icnumber.equals(CusICNum)){
                                found = true;
                                JOptionPane.showMessageDialog(null,"IC number exist","IC Number Existed",JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    }
                }
                if (found == true){
                    int option = JOptionPane.showConfirmDialog(null, "Username or IC number existed do you want to Log In", "Account existed", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null);
                    if (option == JOptionPane.YES_NO_OPTION) {
                        new SignIn().setVisible(true);
                    }
                }else{
                    
                    BufferedWriter BW = new BufferedWriter (new FileWriter(("Customer.txt"),true));
                    BW.write(CusName + ":" + CusICNum + ":" + CusPNum + ":" + CusEAdd + ":" + CusUN + ":" + CusPass +":"+ CusSW + ":" + "Customer");
                    BW.newLine();
                    BW.close();
                    BufferedWriter U = new BufferedWriter (new FileWriter(("User.txt"),true));
                    U.write( CusUN + ":" + CusPass + ":" + CusSW + ":" + "Customer" );
                    U.newLine();
                    U.close();
                    JOptionPane.showMessageDialog(null,"Account created successfully","Gas'N Go",JOptionPane.INFORMATION_MESSAGE);
                }                
            }
            catch(IOException e)
            {
            }
    }
    
    public static void CustomerDetailsUpdate(String Name, String ICNumber, String PhoneNumber, String EmailAddress,String Username,String Password, String SecureWord){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("Customer.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String CusICNum = (records[1]);
                String CusRole = (records[7]);
                if (ICNumber.equals(CusICNum)){
                    modifyArray.add(Name + ":" + CusICNum + ":" + PhoneNumber + ":" + EmailAddress + ":" + Username + ":" + Password +":"+ SecureWord + ":" + CusRole);
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("Customer.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
    
    public static void CustomerDetailsUpdateInUser(String Username,String Password, String SecureWord){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("User.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String CusUsername = (records[0]);
                String CusRole = (records[3]);
                if (Username.equals(CusUsername)){
                    modifyArray.add(Username+ ":" + Password +":"+ SecureWord + ":" + CusRole);
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("User.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }

    
    public static void DeleteCustomerInfo(String ICNumber){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("Customer.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String CusName = (records[0]);
                String CusICNum = (records[1]);
                String CusPhoneNumber = (records[2]);
                String CusEmailAddress = (records[3]);
                String CusUsername = (records[4]);
                String CusPassword = (records[5]);
                String CusSecureWord = (records[6]);
                String CusRole = (records[7]);    
                if (!CusICNum.equals(ICNumber)){
                    modifyArray.add(CusName + ":" + CusICNum + ":" + CusPhoneNumber + ":" + CusEmailAddress + ":" + CusUsername + ":" + CusPassword +":"+ CusSecureWord + ":" + CusRole);
                       
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("Customer.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
    
     public static void DeleteCusUserInfo(String Username){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("User.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String CustomerUN = (records[0]);
                String CustomerPass = (records[1]);
                String SecureWord = (records[2]);
                String UserRole = (records[3]);
                if (!Username.equals(CustomerUN)){
                    modifyArray.add(CustomerUN + ":" + CustomerPass + ":" +SecureWord+ ":" + UserRole );
                    }                
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("User.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
    
    public void CustomerBookCar(){
        try{

            BufferedReader br = new BufferedReader(new FileReader("CarBookings.txt"));
            String line, b = null;
            int lastBookingID, NewBookingID;

            while((line = br.readLine())!= null){
                String[] a = line.split(":");
                b = a[0];
            }
            if (b != null){
                lastBookingID = Integer.parseInt(b);
                NewBookingID = lastBookingID + 1;

            }
            else{
                NewBookingID = 100000;

            }
            BufferedWriter rd = new BufferedWriter(new FileWriter(("CarBookings.txt"), true));
            rd.write(NewBookingID + ":" + CarNoPlate + ":" + CusIC_number + ":" + Car_Model + ":" + Start_Date + ":" + End_Date + ":" + Rent_Fee + ":" + "Pending");
            rd.newLine();
            rd.close();

        }catch(IOException e){
        }
    }
    
        
    public void CustomerPayment(){
        
        try{

            BufferedReader br = new BufferedReader(new FileReader("Payment.txt"));
            String line, b = null;
            int lastPaymentID, NewPaymentID;
            while((line = br.readLine())!= null){
                String[] a = line.split(":");
                b = a[0];
            }
            if (b != null){
                lastPaymentID = Integer.parseInt(b);
                NewPaymentID = lastPaymentID + 1;

            }
            else{
                NewPaymentID = 100000;

            }
            BufferedWriter rd = new BufferedWriter(new FileWriter(("Payment.txt"), true));
            rd.write(NewPaymentID + ":" + Customer_IC_Number + ":" + Customer_Username + ":" + Car_NO_PLATE + ":"+ Customer_CardName + ":" + Customer_CardNumber + ":" + Customer_CVV + ":" + Customer_Month + ":" + Customer_Year + ":"+ Customer_TotalRentalFee + ":" + "Booked" +":"+"-"+":"+"-"+":"+"-");
            rd.newLine();
            rd.close();

        }catch(IOException e){

        }
       
    }   
    
    public Vector returnCar(){
        double amount = 0.00;
        long days = 0;
        double fine = 0.00;
        double totalAmount = 0.00;
        String Status = "Success";
        
        try {
            BufferedReader reader = new BufferedReader(new FileReader("CarBookings.txt"));
            Object [] Lines = reader.lines().toArray();
            boolean e = false;
            for (int i = 0; i < Lines.length; i++){
                String Line = Lines[i].toString().trim();
                String [] Row = Line.split(":");

                if (custICNUMBER.equals(Row[2]) && carNo.equals(Row[1])){
                    String Approval = Row[7];
                    String a = Row[6];
                    amount = Double.parseDouble(a);
                    
                    if (Approval.equals("Approved")){ 
                        String returnDate = Row[5];
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                        LocalDate rd = LocalDate.parse(returnDate,formatter);
                        LocalDate cd = LocalDate.now();
                        if (rd.isBefore(cd)){
                            days = rd.until(cd, ChronoUnit.DAYS);
                            for (int d = 1; d <= days; d++) {
                                fine += 100.00;
                            }
                            totalAmount = amount + fine;
                        }
                        else if (rd.isEqual(cd)){
                            totalAmount = amount;
                        }
                        else if (rd.isAfter(cd)){
                            JOptionPane.showMessageDialog(null, "You still have time to return this car!", "Error", JOptionPane.ERROR_MESSAGE);
                            Status = "Failure";
                        }
                    }
                    else if (Approval.equals("Pending")){
                        JOptionPane.showMessageDialog(null, "Your booking for this car is not confirmed yet!", "Error", JOptionPane.ERROR_MESSAGE);
                        Status = "Failure";
                    }
                    else if (Approval.equals("Declined")){
                        JOptionPane.showMessageDialog(null, "Your booking for this car has been rejected!", "Error", JOptionPane.ERROR_MESSAGE);
                        Status = "Failure";
                    }
                    else if (Approval.equals("Completed")){
                        JOptionPane.showMessageDialog(null, "Your have already returned this car!", "Error", JOptionPane.ERROR_MESSAGE);
                        Status = "Failure";
                    }
                    e = true;
                    break;
                }
            }

            if (e == false) {
                JOptionPane.showMessageDialog(null, "Car not found!", "Error", JOptionPane.ERROR_MESSAGE);
                Status = "Failure";
            }
        }
        catch (IOException e){
            JOptionPane.showMessageDialog(null, "An error occured while returning the car!", "Error", JOptionPane.ERROR_MESSAGE);
        }
        Vector v = new Vector();
        v.add(amount);
        v.add(days);
        v.add(fine);
        v.add(totalAmount);
        v.add(Status);
        return v;
    }
    
    public void ReturnPayment(){
        ArrayList<String> modifyArray = new ArrayList<>();
        String [] records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("Payment.txt"))) {
            while ((line = reader.readLine()) != null) {
                records = line.split(":");
                if (CICN.equals(records[1]) && CCN.equals(records[3])) {
                    modifyArray.add(records[0] + ":" + records[1] + ":" + records[2] + ":" + records[3] + ":" + CN + ":" + CDN + ":" 
                                    +CVVN + ":" + CMN + ":" + CYN + ":" + CarFee + ":" + "Completed" + ":" +  CarFine + ":" + CarTotalFee+":"+ feedback);
                }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();

            try {
                PrintWriter pr = new PrintWriter("Payment.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch (IOException e) {
            }
            
        }

        catch(IOException e){
            JOptionPane.showMessageDialog(null, "An error occured during the payment!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
     public void CompletedBooking(){
        ArrayList<String> modifyArray = new ArrayList<>();
        String [] records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("CarBookings.txt"))) {
            while ((line = reader.readLine()) != null) {
                records = line.split(":");
                if (CICN.equals(records[2]) && CCN.equals(records[1])) {
                    modifyArray.add(records[0] + ":" + records[1] + ":" + records[2] + ":" + records[3] + ":" + records[4] + ":" + records[5]+ ":" 
                                    +records[6] + ":" +"Completed" );
                }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();

            try {
                PrintWriter pr = new PrintWriter("CarBookings.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch (IOException e) {
            }
            
        }

        catch(IOException e){
            JOptionPane.showMessageDialog(null, "An error occured during the payment!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
     
    public static void CustomerProfileUpdate(String CustomerUsername,String N,String IC,String PN,String EA,String UN,String SW){
        
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("Customer.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String CustomerUN = (records[4]);
                String CustomerPass = (records[5]);
                String UserRole = (records[7]);
                if (CustomerUsername.equals(CustomerUN)){
                    modifyArray.add(N + ":" + IC + ":" + PN + ":" + EA +":"+ UN + ":" + CustomerPass + ":" + SW + ":" + UserRole);
                }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("Customer.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Admin details");
        }
    }
    
    public static void CustomerProfileUpdateUser(String CustomerUsername,String UN,String SW){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("User.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String UserName = (records[0]);
                String OldPassword = (records[1]);
                String UserRole = (records[3]);
                if (CustomerUsername.equals(UserName)){
                    modifyArray.add(UN + ":" + OldPassword + ":" + SW + ":" + UserRole );
                    JOptionPane.showMessageDialog(null,"Your Profile has been update succesfully");
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("User.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
    
    public static void CustomerUpdatePassword(String Username,String NewPassword){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("Customer.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String CusName  = (records[0]);
                String CusICNum = (records[1]);
                String CusPNum = (records[2]);
                String CusEAdd = (records[3]);
                String CusUN = (records[4]);
                String CusSW = (records[6]);
                String CusRole = (records[7]);
                if (Username.equals(CusUN)){
                    modifyArray.add(CusName + ":" + CusICNum + ":" + CusPNum + ":" + CusEAdd +":"+ CusUN + ":" + NewPassword + ":" + CusSW + ":" + CusRole);
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("Customer.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
    
    public static void UserUpdatePassword(String Username,String NewPassword){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("User.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String UserName = (records[0]);
                String OldPassword = (records[1]);
                String Secureword = (records[2]);
                String UserRole = (records[3]);
                if (Username.equals(UserName)){
                    modifyArray.add(UserName + ":" + NewPassword + ":" + Secureword + ":" + UserRole );
                    JOptionPane.showMessageDialog(null,"Your Password has been changed succesfully");
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("User.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    
    }
    
    
}


