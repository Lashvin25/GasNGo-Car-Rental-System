
package CarRental.Customer;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class ReturnCar extends javax.swing.JFrame {
    private static String CustomerUsername; 
    private static String Car_NO_plate; 
    
    public ReturnCar(String username, String CarNoPlate) {
        initComponents();
        Toolkit toolkit= getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
        CustomerUsername = username;
        Car_NO_plate = CarNoPlate;
        GetCusICNumber();
        GetDetails();
    }
    
    
    private void GetCusICNumber(){
        String[] records;
        String line;
        File file = new File("Customer.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            while ((line = reader.readLine()) != null) {
                records = line.split(":");
                String CusIcNumber  = (records[1]);
                String CusUN = (records[4]);
                if (CustomerUsername.equals(CusUN)){
                    String GetCusIcNumber = CusIcNumber;
                    FakeLbl.setText(GetCusIcNumber);
                }
            }
            reader.close();
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
    }

    private void GetDetails(){
        String rentamount = String.format("%.02f", ReturnMyCar.getAmount());
        String rentfine = String.format("%.02f", ReturnMyCar.getFine());
        String renttotal = String.format("%.02f", ReturnMyCar.getTotalfee());
        CarNoPlate.setText(Car_NO_plate);
        CarNoPlate.setEditable(false);
        Amount.setText(rentamount);
        DelayedDays.setText(ReturnMyCar.getDays());
        Fine.setText(rentfine);
        lblTotalAmount.setText(renttotal);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        PayNowbtn = new javax.swing.JButton();
        CancelBtn = new javax.swing.JButton();
        lblTotalAmount = new javax.swing.JLabel();
        lblPayableAmount3 = new javax.swing.JLabel();
        RMlbl3 = new javax.swing.JLabel();
        RMlbl = new javax.swing.JLabel();
        Amount = new javax.swing.JLabel();
        Amountlbl = new javax.swing.JLabel();
        DDlbl = new javax.swing.JLabel();
        DelayedDays = new javax.swing.JLabel();
        Fine = new javax.swing.JLabel();
        CarNoPlatelbl = new javax.swing.JLabel();
        RMlbl2 = new javax.swing.JLabel();
        CarNoPlate = new javax.swing.JTextField();
        FakeLbl = new javax.swing.JLabel();
        Line = new javax.swing.JLabel();
        Line1 = new javax.swing.JLabel();
        Line2 = new javax.swing.JLabel();
        Line3 = new javax.swing.JLabel();
        Finelbl = new javax.swing.JLabel();
        Line4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setMaximumSize(new java.awt.Dimension(430, 360));
        jPanel1.setMinimumSize(new java.awt.Dimension(430, 360));
        jPanel1.setLayout(null);

        PayNowbtn.setBackground(new java.awt.Color(0, 0, 0));
        PayNowbtn.setFont(new java.awt.Font("Franklin Gothic Book", 1, 12)); // NOI18N
        PayNowbtn.setForeground(new java.awt.Color(255, 255, 255));
        PayNowbtn.setText("PAY");
        PayNowbtn.setBorder(null);
        PayNowbtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        PayNowbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PayNowbtnActionPerformed(evt);
            }
        });
        jPanel1.add(PayNowbtn);
        PayNowbtn.setBounds(220, 300, 100, 40);

        CancelBtn.setBackground(new java.awt.Color(0, 0, 0));
        CancelBtn.setFont(new java.awt.Font("Franklin Gothic Book", 1, 12)); // NOI18N
        CancelBtn.setForeground(new java.awt.Color(255, 255, 255));
        CancelBtn.setText("CANCEL");
        CancelBtn.setBorder(null);
        CancelBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        CancelBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelBtnActionPerformed(evt);
            }
        });
        jPanel1.add(CancelBtn);
        CancelBtn.setBounds(110, 300, 100, 40);

        lblTotalAmount.setFont(new java.awt.Font("Dialog", 3, 20)); // NOI18N
        lblTotalAmount.setForeground(new java.awt.Color(0, 0, 0));
        lblTotalAmount.setText("0.00");
        jPanel1.add(lblTotalAmount);
        lblTotalAmount.setBounds(200, 234, 90, 26);

        lblPayableAmount3.setFont(new java.awt.Font("Constantia", 3, 16)); // NOI18N
        lblPayableAmount3.setForeground(new java.awt.Color(0, 0, 0));
        lblPayableAmount3.setText("Total Payable Amount:");
        jPanel1.add(lblPayableAmount3);
        lblPayableAmount3.setBounds(130, 210, 180, 20);

        RMlbl3.setFont(new java.awt.Font("Dialog", 3, 20)); // NOI18N
        RMlbl3.setForeground(new java.awt.Color(0, 0, 0));
        RMlbl3.setText("RM");
        jPanel1.add(RMlbl3);
        RMlbl3.setBounds(160, 232, 50, 30);

        RMlbl.setFont(new java.awt.Font("Dialog", 3, 20)); // NOI18N
        RMlbl.setForeground(new java.awt.Color(0, 0, 0));
        RMlbl.setText("RM");
        jPanel1.add(RMlbl);
        RMlbl.setBounds(20, 160, 50, 30);

        Amount.setFont(new java.awt.Font("Dialog", 3, 20)); // NOI18N
        Amount.setForeground(new java.awt.Color(0, 0, 0));
        Amount.setText("0.00");
        jPanel1.add(Amount);
        Amount.setBounds(60, 160, 70, 30);

        Amountlbl.setFont(new java.awt.Font("Constantia", 3, 16)); // NOI18N
        Amountlbl.setForeground(new java.awt.Color(0, 0, 0));
        Amountlbl.setText("Amount:");
        jPanel1.add(Amountlbl);
        Amountlbl.setBounds(30, 130, 70, 30);

        DDlbl.setFont(new java.awt.Font("Constantia", 3, 16)); // NOI18N
        DDlbl.setForeground(new java.awt.Color(0, 0, 0));
        DDlbl.setText("Delay Days:");
        jPanel1.add(DDlbl);
        DDlbl.setBounds(290, 130, 100, 30);

        DelayedDays.setFont(new java.awt.Font("Dialog", 3, 20)); // NOI18N
        DelayedDays.setForeground(new java.awt.Color(255, 0, 0));
        DelayedDays.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        DelayedDays.setText("0");
        jPanel1.add(DelayedDays);
        DelayedDays.setBounds(290, 166, 100, 20);

        Fine.setFont(new java.awt.Font("Dialog", 3, 20)); // NOI18N
        Fine.setForeground(new java.awt.Color(255, 0, 0));
        Fine.setText("0.00");
        jPanel1.add(Fine);
        Fine.setBounds(200, 160, 80, 30);

        CarNoPlatelbl.setFont(new java.awt.Font("Constantia", 3, 16)); // NOI18N
        CarNoPlatelbl.setForeground(new java.awt.Color(0, 0, 0));
        CarNoPlatelbl.setText("Car No Plate:");
        jPanel1.add(CarNoPlatelbl);
        CarNoPlatelbl.setBounds(140, 40, 110, 30);

        RMlbl2.setFont(new java.awt.Font("Dialog", 3, 20)); // NOI18N
        RMlbl2.setForeground(new java.awt.Color(255, 0, 0));
        RMlbl2.setText("RM");
        jPanel1.add(RMlbl2);
        RMlbl2.setBounds(160, 160, 60, 30);

        CarNoPlate.setBackground(new java.awt.Color(255, 255, 255));
        CarNoPlate.setFont(new java.awt.Font("Dialog", 3, 20)); // NOI18N
        CarNoPlate.setForeground(new java.awt.Color(0, 0, 0));
        CarNoPlate.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        CarNoPlate.setBorder(null);
        CarNoPlate.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                CarNoPlateFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                CarNoPlateFocusLost(evt);
            }
        });
        jPanel1.add(CarNoPlate);
        CarNoPlate.setBounds(140, 70, 130, 30);

        FakeLbl.setBackground(new java.awt.Color(255, 204, 255));
        FakeLbl.setForeground(new java.awt.Color(255, 255, 255));
        FakeLbl.setText("Fake");
        jPanel1.add(FakeLbl);
        FakeLbl.setBounds(50, 250, 100, 15);

        Line.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line.setForeground(new java.awt.Color(0, 0, 0));
        Line.setText("________________");
        Line.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel1.add(Line);
        Line.setBounds(290, 180, 110, 16);

        Line1.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line1.setForeground(new java.awt.Color(0, 0, 0));
        Line1.setText("________________________");
        Line1.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel1.add(Line1);
        Line1.setBounds(130, 90, 190, 16);

        Line2.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line2.setForeground(new java.awt.Color(0, 0, 0));
        Line2.setText("__________________");
        Line2.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel1.add(Line2);
        Line2.setBounds(20, 180, 130, 16);

        Line3.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line3.setForeground(new java.awt.Color(0, 0, 0));
        Line3.setText("___________________");
        Line3.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel1.add(Line3);
        Line3.setBounds(150, 180, 130, 16);

        Finelbl.setFont(new java.awt.Font("Constantia", 3, 16)); // NOI18N
        Finelbl.setForeground(new java.awt.Color(0, 0, 0));
        Finelbl.setText("Fine:");
        jPanel1.add(Finelbl);
        Finelbl.setBounds(150, 130, 110, 30);

        Line4.setFont(new java.awt.Font("DialogInput", 0, 11)); // NOI18N
        Line4.setForeground(new java.awt.Color(0, 0, 0));
        Line4.setText("__________________________");
        Line4.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel1.add(Line4);
        Line4.setBounds(130, 250, 190, 16);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 415, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PayNowbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PayNowbtnActionPerformed
        
        ConfirmPayment PM = new ConfirmPayment(CustomerUsername, CarNoPlate.getText(),Amount.getText(),Fine.getText(),lblTotalAmount.getText());
        PM.setVisible(true);
        dispose();
    }//GEN-LAST:event_PayNowbtnActionPerformed

    private void CarNoPlateFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_CarNoPlateFocusLost

    }//GEN-LAST:event_CarNoPlateFocusLost

    private void CarNoPlateFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_CarNoPlateFocusGained

    }//GEN-LAST:event_CarNoPlateFocusGained

    private void CancelBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelBtnActionPerformed
        dispose();
        
    }//GEN-LAST:event_CancelBtnActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReturnCar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReturnCar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReturnCar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReturnCar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReturnCar(CustomerUsername,Car_NO_plate).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Amount;
    private javax.swing.JLabel Amountlbl;
    private javax.swing.JButton CancelBtn;
    private javax.swing.JTextField CarNoPlate;
    private javax.swing.JLabel CarNoPlatelbl;
    private javax.swing.JLabel DDlbl;
    private javax.swing.JLabel DelayedDays;
    private javax.swing.JLabel FakeLbl;
    private javax.swing.JLabel Fine;
    private javax.swing.JLabel Finelbl;
    private javax.swing.JLabel Line;
    private javax.swing.JLabel Line1;
    private javax.swing.JLabel Line2;
    private javax.swing.JLabel Line3;
    private javax.swing.JLabel Line4;
    private javax.swing.JButton PayNowbtn;
    private javax.swing.JLabel RMlbl;
    private javax.swing.JLabel RMlbl2;
    private javax.swing.JLabel RMlbl3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblPayableAmount3;
    private javax.swing.JLabel lblTotalAmount;
    // End of variables declaration//GEN-END:variables
}
