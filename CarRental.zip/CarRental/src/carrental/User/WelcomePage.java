/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package CarRental.User;

import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JOptionPane;



/**
 *
 * @author Lashvin
 */
public class WelcomePage extends javax.swing.JFrame {

    /**
     * Creates new form Test
     */
    public WelcomePage() {
        initComponents();
        Toolkit toolkit= getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        WelcomePageLbl = new javax.swing.JLabel();
        LoadingLabel = new javax.swing.JLabel();
        ProgressBar = new javax.swing.JProgressBar();
        LoadingValue = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(0, 0));
        setMinimumSize(new java.awt.Dimension(1000, 550));
        setUndecorated(true);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setMaximumSize(new java.awt.Dimension(1000, 550));
        jPanel1.setMinimumSize(new java.awt.Dimension(1000, 550));
        jPanel1.setPreferredSize(new java.awt.Dimension(1000, 550));
        jPanel1.setLayout(null);

        WelcomePageLbl.setBackground(new java.awt.Color(255, 255, 255));
        WelcomePageLbl.setForeground(new java.awt.Color(255, 255, 255));
        WelcomePageLbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/carrental/Source/WelcomePage1.gif"))); // NOI18N
        jPanel1.add(WelcomePageLbl);
        WelcomePageLbl.setBounds(230, 40, 560, 450);

        LoadingLabel.setBackground(new java.awt.Color(0, 0, 0));
        LoadingLabel.setForeground(new java.awt.Color(255, 255, 255));
        LoadingLabel.setText("Loading...");
        jPanel1.add(LoadingLabel);
        LoadingLabel.setBounds(10, 510, 262, 15);

        ProgressBar.setValue(50);
        jPanel1.add(ProgressBar);
        ProgressBar.setBounds(0, 530, 1015, 20);

        LoadingValue.setBackground(new java.awt.Color(0, 0, 0));
        LoadingValue.setForeground(new java.awt.Color(255, 255, 255));
        LoadingValue.setText("0%");
        jPanel1.add(LoadingValue);
        LoadingValue.setBounds(960, 510, 34, 15);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 1000, 550);

        pack();
    }// </editor-fold>//GEN-END:initComponents


    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals (info.getName())) {
                    javax. swing. UIManager. setLookAndFeel (info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex){
            java.util.logging.Logger.getLogger(WelcomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex){
            java.util.logging.Logger.getLogger(WelcomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex){
            java.util.logging.Logger.getLogger(WelcomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex){
            java.util.logging.Logger.getLogger(WelcomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
      WelcomePage tp = new WelcomePage();
      tp.setVisible(true);
        
        try{  
            for(int i=0;i<101;i++){
                Thread.sleep(100);
                tp.LoadingValue.setText(i + "%");
                
                if(i==10){
                    tp.LoadingLabel.setText("Turning On Modules...");
                }
                if(i==20){
                    tp.LoadingLabel.setText("Loading Modules...");
                }
                if(i==50){
                    tp.LoadingLabel.setText("Connecting to Database...");
                }
                if(i==70){
                    tp.LoadingLabel.setText("Connection Successful..");
                }
                if(i==80){
                    tp.LoadingLabel.setText("Launching Application..");
                }
                tp.ProgressBar.setValue(i);
                if(i==100){
                    SignIn lp = new SignIn();
                    lp.setVisible(true);
                    tp.setVisible(false);
                }
                
            }
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
            
        
        } 
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LoadingLabel;
    private javax.swing.JLabel LoadingValue;
    private javax.swing.JProgressBar ProgressBar;
    private javax.swing.JLabel WelcomePageLbl;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
