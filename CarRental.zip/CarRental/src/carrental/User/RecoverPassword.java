/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package CarRental.User;

import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JOptionPane;

/**
 *
 * @author Lashvin
 */
public class RecoverPassword extends javax.swing.JFrame {
    private static String UN;
    private static String SW;

    public RecoverPassword(String Username,String SecureWord) {
        initComponents();
        UN = Username;
        SW = SecureWord;
        Toolkit toolkit= getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        FPpanel = new javax.swing.JPanel();
        FPlbl = new javax.swing.JLabel();
        Line1 = new javax.swing.JLabel();
        PWlbl = new javax.swing.JLabel();
        Passwordtxt = new javax.swing.JTextField();
        FPlbl4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        Line2 = new javax.swing.JLabel();
        ConfirmBtn = new javax.swing.JButton();
        FPlbl7 = new javax.swing.JLabel();
        ConfirmPasswordtxt = new javax.swing.JTextField();
        Line3 = new javax.swing.JLabel();
        FPlbl9 = new javax.swing.JLabel();
        CPWlbl = new javax.swing.JLabel();
        Backgroundlbl = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 550));
        setUndecorated(true);
        getContentPane().setLayout(null);

        FPpanel.setBackground(new java.awt.Color(255, 255, 255));
        FPpanel.setForeground(new java.awt.Color(255, 255, 255));
        FPpanel.setLayout(null);

        FPlbl.setBackground(new java.awt.Color(0, 0, 0));
        FPlbl.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        FPlbl.setForeground(new java.awt.Color(0, 0, 0));
        FPlbl.setText("Change Password");
        FPpanel.add(FPlbl);
        FPlbl.setBounds(390, 30, 210, 70);

        Line1.setFont(new java.awt.Font("DialogInput", 0, 24)); // NOI18N
        Line1.setForeground(new java.awt.Color(0, 0, 0));
        Line1.setText("______________");
        Line1.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        FPpanel.add(Line1);
        Line1.setBounds(470, 180, 270, 33);

        PWlbl.setBackground(new java.awt.Color(0, 0, 0));
        PWlbl.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        PWlbl.setForeground(new java.awt.Color(102, 102, 102));
        PWlbl.setText("Must be at least 5 characters");
        FPpanel.add(PWlbl);
        PWlbl.setBounds(480, 210, 220, 20);

        Passwordtxt.setBackground(new java.awt.Color(255, 255, 255));
        Passwordtxt.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        Passwordtxt.setBorder(null);
        FPpanel.add(Passwordtxt);
        Passwordtxt.setBounds(480, 170, 200, 40);

        FPlbl4.setBackground(new java.awt.Color(0, 0, 0));
        FPlbl4.setFont(new java.awt.Font("Rockwell", 1, 14)); // NOI18N
        FPlbl4.setForeground(new java.awt.Color(0, 0, 0));
        FPlbl4.setText("Password:");
        FPpanel.add(FPlbl4);
        FPlbl4.setBounds(470, 150, 270, 18);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/carrental/Source/Password1.gif"))); // NOI18N
        FPpanel.add(jLabel1);
        jLabel1.setBounds(50, 60, 360, 340);

        Line2.setFont(new java.awt.Font("DialogInput", 0, 24)); // NOI18N
        Line2.setForeground(new java.awt.Color(0, 0, 0));
        Line2.setText("_______________________________");
        Line2.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        FPpanel.add(Line2);
        Line2.setBounds(390, 60, 450, 33);

        ConfirmBtn.setFont(new java.awt.Font("Franklin Gothic Book", 1, 12)); // NOI18N
        ConfirmBtn.setText("CONFIRM");
        ConfirmBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ConfirmBtnMouseClicked(evt);
            }
        });
        FPpanel.add(ConfirmBtn);
        ConfirmBtn.setBounds(480, 360, 190, 40);

        FPlbl7.setBackground(new java.awt.Color(0, 0, 0));
        FPlbl7.setFont(new java.awt.Font("Dialog", 2, 14)); // NOI18N
        FPlbl7.setForeground(new java.awt.Color(102, 102, 102));
        FPlbl7.setText("Your new password must be different from previous used passwords.");
        FPpanel.add(FPlbl7);
        FPlbl7.setBounds(390, 100, 460, 18);

        ConfirmPasswordtxt.setBackground(new java.awt.Color(255, 255, 255));
        ConfirmPasswordtxt.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        ConfirmPasswordtxt.setBorder(null);
        FPpanel.add(ConfirmPasswordtxt);
        ConfirmPasswordtxt.setBounds(480, 270, 200, 40);

        Line3.setFont(new java.awt.Font("DialogInput", 0, 24)); // NOI18N
        Line3.setForeground(new java.awt.Color(0, 0, 0));
        Line3.setText("______________");
        Line3.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        FPpanel.add(Line3);
        Line3.setBounds(470, 280, 270, 33);

        FPlbl9.setBackground(new java.awt.Color(0, 0, 0));
        FPlbl9.setFont(new java.awt.Font("Rockwell", 1, 14)); // NOI18N
        FPlbl9.setForeground(new java.awt.Color(0, 0, 0));
        FPlbl9.setText("Confirm Password:");
        FPpanel.add(FPlbl9);
        FPlbl9.setBounds(470, 250, 270, 18);

        CPWlbl.setBackground(new java.awt.Color(0, 0, 0));
        CPWlbl.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        CPWlbl.setForeground(new java.awt.Color(102, 102, 102));
        CPWlbl.setText("Both passwords must match");
        FPpanel.add(CPWlbl);
        CPWlbl.setBounds(480, 310, 220, 20);

        getContentPane().add(FPpanel);
        FPpanel.setBounds(50, 50, 900, 450);

        Backgroundlbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/carrental/Source/Gradient.jpg"))); // NOI18N
        getContentPane().add(Backgroundlbl);
        Backgroundlbl.setBounds(0, -10, 1000, 570);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ConfirmBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ConfirmBtnMouseClicked
        String P = Passwordtxt.getText();
        String CP = ConfirmPasswordtxt.getText();
        if(P.equals(""))
        {
            JOptionPane.showMessageDialog(null,"Please enter your new password","Error",JOptionPane.ERROR_MESSAGE);
        }
        else if(P.length()<5){
            JOptionPane.showMessageDialog(null,"Your Password must be atleast 5 characters","Error",JOptionPane.ERROR_MESSAGE);
        }   
        else if(!P.equals(CP))
        {
           JOptionPane.showMessageDialog(null,"Both Password must be same","Error",JOptionPane.ERROR_MESSAGE);

        } 
        else{
            User.RecoverPassword(UN, SW,CP);
            User.CustomerRecoverPassword(UN, SW,CP);
            dispose();  
        }
        
        
        
    }//GEN-LAST:event_ConfirmBtnMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RecoverPassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RecoverPassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RecoverPassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RecoverPassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RecoverPassword(UN,SW).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Backgroundlbl;
    private javax.swing.JLabel CPWlbl;
    private javax.swing.JButton ConfirmBtn;
    private javax.swing.JTextField ConfirmPasswordtxt;
    private javax.swing.JLabel FPlbl;
    private javax.swing.JLabel FPlbl4;
    private javax.swing.JLabel FPlbl7;
    private javax.swing.JLabel FPlbl9;
    private javax.swing.JPanel FPpanel;
    private javax.swing.JLabel Line1;
    private javax.swing.JLabel Line2;
    private javax.swing.JLabel Line3;
    private javax.swing.JLabel PWlbl;
    private javax.swing.JTextField Passwordtxt;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
