/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package CarRental.User;

import java.awt.Dimension;
import java.awt.Toolkit;

/**
 *
 * @author Lashvin
 */
public class SignUpThankYou extends javax.swing.JFrame {

    /**
     * Creates new form SignUpThankYou
     */
    public SignUpThankYou() {
        initComponents();
        Toolkit toolkit= getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
    }
    
    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LoginPagePanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        SignInLabel = new javax.swing.JLabel();
        SignUpQLabel2 = new javax.swing.JLabel();
        SignUpLabel1 = new javax.swing.JLabel();
        LoginPageLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 550));
        setUndecorated(true);
        getContentPane().setLayout(null);

        LoginPagePanel2.setBackground(new java.awt.Color(250, 250, 250,150));
        LoginPagePanel2.setLayout(null);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/carrental/Source/ApproveBadge.png"))); // NOI18N
        LoginPagePanel2.add(jLabel1);
        jLabel1.setBounds(320, 40, 260, 240);

        SignInLabel.setBackground(new java.awt.Color(0, 0, 0));
        SignInLabel.setFont(new java.awt.Font("Ebrima", 1, 36)); // NOI18N
        SignInLabel.setForeground(new java.awt.Color(0, 0, 0));
        SignInLabel.setText("Thanks for Signing Up!");
        LoginPagePanel2.add(SignInLabel);
        SignInLabel.setBounds(260, 260, 440, 70);

        SignUpQLabel2.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        SignUpQLabel2.setForeground(new java.awt.Color(0, 0, 0));
        SignUpQLabel2.setText("We have successfully created your account,Please click                    ");
        LoginPagePanel2.add(SignUpQLabel2);
        SignUpQLabel2.setBounds(280, 330, 300, 15);

        SignUpLabel1.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        SignUpLabel1.setForeground(new java.awt.Color(0, 0, 255));
        SignUpLabel1.setText("Sign In");
        SignUpLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SignUpLabel1MouseClicked(evt);
            }
        });
        LoginPagePanel2.add(SignUpLabel1);
        SignUpLabel1.setBounds(580, 330, 70, 15);

        getContentPane().add(LoginPagePanel2);
        LoginPagePanel2.setBounds(50, 50, 900, 450);

        LoginPageLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/carrental/Source/Gradient.jpg"))); // NOI18N
        getContentPane().add(LoginPageLabel1);
        LoginPageLabel1.setBounds(0, 0, 1000, 550);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SignUpLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SignUpLabel1MouseClicked
        SignIn CSU = new SignIn();
        CSU.setVisible(true);
        dispose();
    }//GEN-LAST:event_SignUpLabel1MouseClicked

    public static void main(String args[]) {
       
       java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SignUpThankYou().setVisible(true);
            }
        });
       
    }
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LoginPageLabel1;
    private javax.swing.JPanel LoginPagePanel2;
    private javax.swing.JLabel SignInLabel;
    private javax.swing.JLabel SignUpLabel1;
    private javax.swing.JLabel SignUpQLabel2;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
