
package CarRental.User;


import CarRental.Customer.CustomerMenu;
import CarRental.Superuser.SuperUserMenu;
import carrental.Admin.AdminMainMenu;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class User {
    public String CRusername;
    public String CRpassword;
    
    public String Login(String username, String password){
        String message = null;
        CRusername = username;
        CRpassword = password;
        
        try{
            BufferedReader reader = new BufferedReader(new FileReader("User.txt"));
            Object [] Lines = reader.lines().toArray();
            boolean a = false;
            for(int i = 0; i < Lines.length; i++){
                String Line = Lines[i].toString().trim();
                String [] Row = Line.split(":");
                LocalDateTime currentTimestamp = LocalDateTime.now();
                if (CRusername.equals(Row[0])&& CRpassword.equals(Row[1])){
                    a = true;
                    message = "User Found";
                    String AllUserRole = Row[3];
                    String UserName = Row[0];
                    if (AllUserRole.equals("Superuser")){
                        SuperUserMenu SU = new SuperUserMenu(UserName);
                        SU.setVisible(true);
                        Log attempt = new Log();
                        attempt.setusername(CRusername);
                        attempt.setLoginTimestamp(currentTimestamp);
                        attempt.setAttemptResult(1);
                    }
                    if (AllUserRole.equals("Admin")){
                           AdminMainMenu ADM = new AdminMainMenu(UserName);
                           ADM.setVisible(true);
                           Log attempt = new Log();
                           attempt.setusername(CRusername);
                           attempt.setLoginTimestamp(currentTimestamp);
                           attempt.setAttemptResult(1);
                    }
                    if (AllUserRole.equals("Customer")){
                       CustomerMenu CUST = new CustomerMenu(UserName);
                       CUST.setVisible(true);
                       Log attempt = new Log();
                       attempt.setusername(CRusername);
                       attempt.setLoginTimestamp(currentTimestamp);
                       attempt.setAttemptResult(1);
                    }
                }
            }
                    
            if (a == false){
                LocalDateTime currentTimestamp = LocalDateTime.now();
                JOptionPane.showMessageDialog(null,"Invalid login credentials!","Error",JOptionPane.ERROR_MESSAGE);
                Log attempt = new Log();
                attempt.setusername(CRusername);
                attempt.setLoginTimestamp(currentTimestamp);
                attempt.setAttemptResult(0);
                logAttempt();
            }        
        }
        catch (IOException a){
                JOptionPane.showMessageDialog(null,"An Error Occured While Logging In, Please Try Again","Error",JOptionPane.ERROR_MESSAGE);
        }
        return message;
    }
    public static void RecoverPassword(String Username, String SecureWord,String NewPassword){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("User.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String UserName = (records[0]);
                String OldPassword = (records[1]);
                String Secureword = (records[2]);
                String UserRole = (records[3]);
                if (Username.equals(UserName)){
                    if(SecureWord.equals(Secureword)){
                        modifyArray.add(UserName + ":" + NewPassword + ":" + Secureword + ":" + UserRole );
                        JOptionPane.showMessageDialog(null,"Your Password has been changed succesfully");
                        SignIn SI = new SignIn();
                        SI.setVisible(true);
                    }
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("User.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
        
    public static void AdminRecoverPassword(String Username, String SecureWord,String NewPassword){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("Admin.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String AdmName  = (records[0]);
                String AdmICNum = (records[1]);
                String AdmPNum = (records[2]);
                String AdmEAdd = (records[3]);
                String AdmHAdd = (records[4]);
                String AdmGender = (records[5]);
                String AdmUN = (records[6]);
                String AdmSW = (records[8]);
                String AdmRole = (records[9]);
                if (Username.equals(AdmUN)){
                    if(SecureWord.equals(AdmSW)){
                        modifyArray.add(AdmName + ":" + AdmICNum + ":" + AdmPNum + ":" + AdmEAdd + ":" + AdmHAdd + ":" + AdmGender +":"+ AdmUN + ":" + NewPassword + ":" + AdmSW + ":" + AdmRole);
                        SignIn SI = new SignIn();
                        SI.setVisible(true);
                    }
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("Admin.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
        
    public static void CustomerRecoverPassword(String Username, String SecureWord,String NewPassword){
        ArrayList <String> modifyArray = new ArrayList<>();
        String []records;
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("Customer.txt"))){
            while ((line = reader.readLine())!=null){
                records = line.split(":");
                String CusName  = (records[0]);
                String CusICNum = (records[1]);
                String CusPNum = (records[2]);
                String CusEAdd = (records[3]);
                String CusUN = (records[4]);
                String CusSW = (records[6]);
                String CusRole = (records[7]);
                if (Username.equals(CusUN)){
                    if(SecureWord.equals(CusSW)){
                        modifyArray.add(CusName + ":" + CusICNum + ":" + CusPNum + ":" + CusEAdd + ":"+ CusUN + ":" + NewPassword + ":" + CusSW + ":" + CusRole);
                        SignIn SI = new SignIn();
                        SI.setVisible(true);
                    }
                    }
                else {
                    modifyArray.add(line);
                }
            }
            reader.close();
            try {
                PrintWriter pr = new PrintWriter("Customer.txt");
                for (String str : modifyArray){
                    pr.println(str);
                }
                pr.close();
            }
            catch(IOException e){
            JOptionPane.showMessageDialog(null,"System Error!");
            }
          
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,"An error while update the Password");
        }
    }
        
    public static void logAttempt()
    {
        File LoginData = new File("LoginData.txt");
        
        if(LoginData.exists())
        {
            try{
                BufferedReader input = new BufferedReader(new FileReader("LoginData.txt"));
                String id = null, line;
                
                while ((line = input.readLine()) != null) { 
                    String[] Records = line.split(":");
                    id = Records[0];
                }
                int last_id, log_id;
                
                if (id != null)
                {
                    last_id = Integer.parseInt(id);
                    log_id = last_id + 1;
                }else{
                    log_id = 1;
                }
                String duration = null, hourText;
                if (Log.getLogoutTimestamp() != null){
                    long hr = ChronoUnit.HOURS.between(Log.getLoginTimestamp(), Log.getLogoutTimestamp());
                    long min = ChronoUnit.MINUTES.between(Log.getLoginTimestamp(), Log.getLogoutTimestamp());
                    long sec = ChronoUnit.SECONDS.between(Log.getLoginTimestamp(), Log.getLogoutTimestamp());
                    if (hr > 1)
                    {
                        hourText = "hours";
                    }else{
                        hourText = " hour ";
                    }
                    duration = hr + hourText + min + " minutes" + sec + " seconds";                    
                }
                BufferedWriter LoginDataFile = new BufferedWriter(new FileWriter(("LoginData.txt"), true));
                LoginDataFile.write(log_id + ":" + Log.getusername() + ":" + Log.getLoginTimestamp() + ":" + Log.getLogoutTimestamp() + ":" + duration + ":" + Log.getAttemptResult());
                LoginDataFile.newLine();
                LoginDataFile.close();  
            }
            catch(IOException e)
            {
                
            }
        }
        else
        {
            try{
                LoginData.createNewFile(); 
                new SignIn().setVisible(true); 
            }
            catch(IOException e)
            {
            }
        }
    }
    
}