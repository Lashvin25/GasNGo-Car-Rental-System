
package CarRental.User;

import java.time.LocalDateTime;


public class Log {
    private static String username;
    private static LocalDateTime loginTimestamp;
    private static LocalDateTime logoutTimestamp;
    private static int attemptResult;

    public static String getusername() {
        return username;
    }

    public void setusername(String username) {
        this.username = username;
    }

    public static LocalDateTime getLoginTimestamp() {
        return loginTimestamp;
    }

    public void setLoginTimestamp(LocalDateTime loginTimestamp) {
        this.loginTimestamp = loginTimestamp;
    }

    public static LocalDateTime getLogoutTimestamp() {
        return logoutTimestamp;
    }

    public static void setLogoutTimestamp(LocalDateTime logoutTimestamp) {
        Log.logoutTimestamp = logoutTimestamp;
    }

    public static int getAttemptResult() {
        return attemptResult;
    }

    public void setAttemptResult(int attemptResult) {
        this.attemptResult = attemptResult;
    }
    
}
